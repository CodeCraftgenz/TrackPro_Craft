"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MfaService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MfaService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const { authenticator } = require('otplib');
const QRCode = __importStar(require("qrcode"));
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../integrations/encryption.service");
let MfaService = MfaService_1 = class MfaService {
    configService;
    prisma;
    encryptionService;
    logger = new common_1.Logger(MfaService_1.name);
    issuer;
    constructor(configService, prisma, encryptionService) {
        this.configService = configService;
        this.prisma = prisma;
        this.encryptionService = encryptionService;
        this.issuer = this.configService.get('MFA_ISSUER', 'TrackPro');
        authenticator.options = {
            digits: 6,
            step: 30,
            window: 1,
        };
    }
    async setupMfa(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: { id: true, email: true, mfaEnabled: true },
        });
        if (!user) {
            throw new common_1.BadRequestException('User not found');
        }
        if (user.mfaEnabled) {
            throw new common_1.BadRequestException('MFA is already enabled for this user');
        }
        const secret = authenticator.generateSecret();
        const otpauthUrl = authenticator.keyuri(user.email, this.issuer, secret);
        const qrCodeUrl = await QRCode.toDataURL(otpauthUrl);
        const backupCodes = this.generateBackupCodes(8);
        const encryptedSecret = this.encryptionService.encrypt(secret);
        const hashedBackupCodes = backupCodes.map((code) => this.encryptionService.hash(code));
        await this.prisma.user.update({
            where: { id: userId },
            data: {
                mfaSecret: encryptedSecret,
                mfaBackupCodes: JSON.stringify(hashedBackupCodes),
                mfaPendingSetup: true,
            },
        });
        this.logger.log(`MFA setup initiated for user ${userId}`);
        return {
            secret,
            qrCodeUrl,
            backupCodes,
        };
    }
    async verifyAndEnableMfa(userId, token) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: {
                id: true,
                mfaSecret: true,
                mfaPendingSetup: true,
                mfaEnabled: true,
            },
        });
        if (!user || !user.mfaSecret || !user.mfaPendingSetup) {
            throw new common_1.BadRequestException('MFA setup not initiated');
        }
        if (user.mfaEnabled) {
            throw new common_1.BadRequestException('MFA is already enabled');
        }
        const secret = this.encryptionService.decrypt(user.mfaSecret);
        const isValid = authenticator.verify({ token, secret });
        if (!isValid) {
            throw new common_1.BadRequestException('Invalid verification code');
        }
        await this.prisma.user.update({
            where: { id: userId },
            data: {
                mfaEnabled: true,
                mfaPendingSetup: false,
            },
        });
        this.logger.log(`MFA enabled for user ${userId}`);
        return true;
    }
    async verifyMfaToken(userId, token) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: {
                id: true,
                mfaSecret: true,
                mfaEnabled: true,
                mfaBackupCodes: true,
            },
        });
        if (!user || !user.mfaEnabled || !user.mfaSecret) {
            throw new common_1.BadRequestException('MFA not enabled for this user');
        }
        const secret = this.encryptionService.decrypt(user.mfaSecret);
        const isValidTotp = authenticator.verify({ token, secret });
        if (isValidTotp) {
            return { success: true, backupCodeUsed: false };
        }
        if (user.mfaBackupCodes) {
            const backupCodes = JSON.parse(user.mfaBackupCodes);
            const tokenHash = this.encryptionService.hash(token);
            const codeIndex = backupCodes.indexOf(tokenHash);
            if (codeIndex !== -1) {
                backupCodes.splice(codeIndex, 1);
                await this.prisma.user.update({
                    where: { id: userId },
                    data: {
                        mfaBackupCodes: JSON.stringify(backupCodes),
                    },
                });
                this.logger.warn(`Backup code used for user ${userId}. Remaining: ${backupCodes.length}`);
                return { success: true, backupCodeUsed: true };
            }
        }
        return { success: false };
    }
    async disableMfa(userId, token) {
        const result = await this.verifyMfaToken(userId, token);
        if (!result.success) {
            throw new common_1.BadRequestException('Invalid verification code');
        }
        await this.prisma.user.update({
            where: { id: userId },
            data: {
                mfaEnabled: false,
                mfaSecret: null,
                mfaBackupCodes: null,
                mfaPendingSetup: false,
            },
        });
        this.logger.log(`MFA disabled for user ${userId}`);
        return true;
    }
    async regenerateBackupCodes(userId, token) {
        const result = await this.verifyMfaToken(userId, token);
        if (!result.success) {
            throw new common_1.BadRequestException('Invalid verification code');
        }
        const backupCodes = this.generateBackupCodes(8);
        const hashedBackupCodes = backupCodes.map((code) => this.encryptionService.hash(code));
        await this.prisma.user.update({
            where: { id: userId },
            data: {
                mfaBackupCodes: JSON.stringify(hashedBackupCodes),
            },
        });
        this.logger.log(`Backup codes regenerated for user ${userId}`);
        return backupCodes;
    }
    async isMfaEnabled(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: { mfaEnabled: true },
        });
        return user?.mfaEnabled ?? false;
    }
    async getMfaStatus(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: { mfaEnabled: true, mfaBackupCodes: true },
        });
        if (!user) {
            throw new common_1.BadRequestException('User not found');
        }
        let backupCodesRemaining = 0;
        if (user.mfaBackupCodes) {
            const codes = JSON.parse(user.mfaBackupCodes);
            backupCodesRemaining = codes.length;
        }
        return {
            enabled: user.mfaEnabled ?? false,
            backupCodesRemaining,
        };
    }
    generateBackupCodes(count) {
        const codes = [];
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        for (let i = 0; i < count; i++) {
            let code = '';
            for (let j = 0; j < 8; j++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            codes.push(`${code.slice(0, 4)}-${code.slice(4)}`);
        }
        return codes;
    }
};
exports.MfaService = MfaService;
exports.MfaService = MfaService = MfaService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService])
], MfaService);
//# sourceMappingURL=mfa.service.js.map