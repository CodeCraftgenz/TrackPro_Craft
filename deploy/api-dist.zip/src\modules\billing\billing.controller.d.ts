import { RawBodyRequest } from '@nestjs/common';
import { Request } from 'express';
import { BillingService } from './billing.service';
import { PlansService } from './plans.service';
import { CreateCheckoutSessionDto, CreatePortalSessionDto, UpdateStripePriceIdsDto } from './billing.dto';
interface AuthenticatedUser {
    userId: string;
    email: string;
    tenantId: string;
    role: string;
}
export declare class BillingController {
    private readonly billingService;
    private readonly plansService;
    constructor(billingService: BillingService, plansService: PlansService);
    getPlans(): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        retentionDays: number;
        isActive: boolean;
        tier: import("@prisma/client").$Enums.PlanTier;
        monthlyPrice: number;
        yearlyPrice: number;
        stripePriceIdMonthly: string | null;
        stripePriceIdYearly: string | null;
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        features: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
    getPlanComparison(): Promise<{
        plans: {
            id: string;
            name: string;
            tier: import("@prisma/client").$Enums.PlanTier;
            description: string | null;
            monthlyPrice: number;
            yearlyPrice: number;
            limits: {
                projects: string | number;
                eventsPerMonth: string;
                teamMembers: string | number;
                retentionDays: number;
            };
        }[];
        features: {
            availability: Record<import("@prisma/client").$Enums.PlanTier, boolean>;
            key: string;
            label: string;
        }[];
    }>;
    handleStripeWebhook(req: RawBodyRequest<Request>, signature: string): Promise<{
        received: boolean;
        error: string;
    } | {
        received: boolean;
        error?: undefined;
    }>;
    getSubscription(user: AuthenticatedUser): Promise<import("./billing.service").SubscriptionDetails | null>;
    getUsageSummary(user: AuthenticatedUser): Promise<import("./billing.service").UsageSummary>;
    getInvoices(user: AuthenticatedUser, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        status: import("@prisma/client").$Enums.PaymentStatus;
        subscriptionId: string;
        periodStart: Date;
        periodEnd: Date;
        stripeInvoiceId: string | null;
        amountDue: number;
        amountPaid: number;
        currency: string;
        invoiceUrl: string | null;
        invoicePdf: string | null;
        dueDate: Date | null;
        paidAt: Date | null;
    }[]>;
    createCheckoutSession(user: AuthenticatedUser, dto: CreateCheckoutSessionDto): Promise<{
        url: string;
    }>;
    createPortalSession(user: AuthenticatedUser, dto: CreatePortalSessionDto): Promise<{
        url: string;
    }>;
    cancelSubscription(user: AuthenticatedUser): Promise<void>;
    resumeSubscription(user: AuthenticatedUser): Promise<void>;
    checkPlanLimit(user: AuthenticatedUser, limitType: 'projects' | 'events' | 'team_members'): Promise<{
        allowed: boolean;
        current: number;
        limit: number;
    }>;
    updateStripePriceIds(dto: UpdateStripePriceIdsDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        retentionDays: number;
        isActive: boolean;
        tier: import("@prisma/client").$Enums.PlanTier;
        monthlyPrice: number;
        yearlyPrice: number;
        stripePriceIdMonthly: string | null;
        stripePriceIdYearly: string | null;
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        features: import("@prisma/client/runtime/library").JsonValue;
    }>;
}
export {};
//# sourceMappingURL=billing.controller.d.ts.map