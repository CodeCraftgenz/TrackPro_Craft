export declare enum LeadPlatform {
    FACEBOOK = "FACEBOOK",
    INSTAGRAM = "INSTAGRAM",
    TWITTER = "TWITTER",
    WEBSITE = "WEBSITE"
}
export declare class CreateLeadIntegrationDto {
    platform: LeadPlatform;
    accessToken?: string;
    refreshToken?: string;
    pageId?: string;
    pageName?: string;
    formIds?: string[];
}
export declare class UpdateLeadIntegrationDto {
    accessToken?: string;
    refreshToken?: string;
    pageId?: string;
    pageName?: string;
    formIds?: string[];
    enabled?: boolean;
}
export declare class FormFieldDto {
    name: string;
    label: string;
    type: string;
    required: boolean;
    options?: string[];
}
export declare class FormStylingDto {
    primaryColor?: string;
    backgroundColor?: string;
    textColor?: string;
    buttonText?: string;
    successMessage?: string;
}
export declare class CreateLeadFormDto {
    name: string;
    fields: FormFieldDto[];
    styling?: FormStylingDto;
    redirectUrl?: string;
}
export declare class UpdateLeadFormDto {
    name?: string;
    fields?: FormFieldDto[];
    styling?: FormStylingDto;
    redirectUrl?: string;
    enabled?: boolean;
}
export declare class CaptureLeadDto {
    formId: string;
    data: Record<string, unknown>;
    source?: string;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
    referrer?: string;
    page_url?: string;
}
export declare class CreateNotificationConfigDto {
    email?: string;
    webhookUrl?: string;
    platforms: LeadPlatform[];
}
export declare class UpdateNotificationConfigDto {
    email?: string;
    webhookUrl?: string;
    platforms?: LeadPlatform[];
    enabled?: boolean;
}
export declare class WebhookLeadDto {
    name?: string;
    email?: string;
    phone?: string;
    custom?: Record<string, unknown>;
    utm_source?: string;
    utm_medium?: string;
    utm_campaign?: string;
    referrer?: string;
    page_url?: string;
}
export declare class LeadQueryDto {
    startDate?: string;
    endDate?: string;
    platform?: LeadPlatform;
    formId?: string;
    limit?: number;
    offset?: number;
}
//# sourceMappingURL=leads.dto.d.ts.map