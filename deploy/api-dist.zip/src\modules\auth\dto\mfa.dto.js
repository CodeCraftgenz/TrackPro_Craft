"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginWithMfaDto = exports.MfaStatusResponseDto = exports.MfaSetupResponseDto = exports.RegenerateBackupCodesDto = exports.DisableMfaDto = exports.VerifyMfaDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class VerifyMfaDto {
    token;
}
exports.VerifyMfaDto = VerifyMfaDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '6-digit TOTP code or backup code',
        example: '123456',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], VerifyMfaDto.prototype, "token", void 0);
class DisableMfaDto {
    token;
}
exports.DisableMfaDto = DisableMfaDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '6-digit TOTP code to confirm disable',
        example: '123456',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.Length)(6, 9),
    __metadata("design:type", String)
], DisableMfaDto.prototype, "token", void 0);
class RegenerateBackupCodesDto {
    token;
}
exports.RegenerateBackupCodesDto = RegenerateBackupCodesDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '6-digit TOTP code to confirm regeneration',
        example: '123456',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.Length)(6, 6),
    __metadata("design:type", String)
], RegenerateBackupCodesDto.prototype, "token", void 0);
class MfaSetupResponseDto {
    secret;
    qrCodeUrl;
    backupCodes;
}
exports.MfaSetupResponseDto = MfaSetupResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'TOTP secret (show only once)' }),
    __metadata("design:type", String)
], MfaSetupResponseDto.prototype, "secret", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'QR code as data URL' }),
    __metadata("design:type", String)
], MfaSetupResponseDto.prototype, "qrCodeUrl", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Backup codes (show only once)' }),
    __metadata("design:type", Array)
], MfaSetupResponseDto.prototype, "backupCodes", void 0);
class MfaStatusResponseDto {
    enabled;
    backupCodesRemaining;
}
exports.MfaStatusResponseDto = MfaStatusResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Whether MFA is enabled' }),
    __metadata("design:type", Boolean)
], MfaStatusResponseDto.prototype, "enabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Number of backup codes remaining' }),
    __metadata("design:type", Number)
], MfaStatusResponseDto.prototype, "backupCodesRemaining", void 0);
class LoginWithMfaDto {
    email;
    password;
    mfaToken;
}
exports.LoginWithMfaDto = LoginWithMfaDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Email address' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], LoginWithMfaDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Password' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], LoginWithMfaDto.prototype, "password", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'MFA token (if MFA is enabled)' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], LoginWithMfaDto.prototype, "mfaToken", void 0);
//# sourceMappingURL=mfa.dto.js.map