export declare class TenantsModule {
}
//# sourceMappingURL=tenants.module.d.ts.map