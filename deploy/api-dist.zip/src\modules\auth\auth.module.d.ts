export declare class AuthModule {
}
//# sourceMappingURL=auth.module.d.ts.map