import { ConfigService } from '@nestjs/config';
import { MemberRole, LeadPlatform } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../integrations/encryption.service';
import { ClickHouseService } from '../analytics/clickhouse.service';
import { CreateLeadIntegrationDto, UpdateLeadIntegrationDto, CreateLeadFormDto, UpdateLeadFormDto, CaptureLeadDto, CreateNotificationConfigDto, UpdateNotificationConfigDto, LeadQueryDto, WebhookLeadDto } from './dto/leads.dto';
export declare class LeadsService {
    private readonly prisma;
    private readonly encryption;
    private readonly clickhouse;
    private readonly configService;
    private readonly logger;
    constructor(prisma: PrismaService, encryption: EncryptionService, clickhouse: ClickHouseService, configService: ConfigService);
    getIntegrations(projectId: string, tenantId: string, userId: string): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        lastSyncAt: Date | null;
        errorMessage: string | null;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    getIntegration(projectId: string, tenantId: string, userId: string, platform: LeadPlatform): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        lastSyncAt: Date | null;
        errorMessage: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        createdAt: Date;
        updatedAt: Date;
    } | null>;
    createIntegration(projectId: string, tenantId: string, userId: string, dto: CreateLeadIntegrationDto): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        webhookSecret: string | null;
        hasAccessToken: boolean;
        createdAt: Date;
    }>;
    updateIntegration(projectId: string, tenantId: string, userId: string, platform: LeadPlatform, dto: UpdateLeadIntegrationDto): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        updatedAt: Date;
    }>;
    deleteIntegration(projectId: string, tenantId: string, userId: string, platform: LeadPlatform): Promise<void>;
    getForms(projectId: string, tenantId: string, userId: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }[]>;
    getForm(projectId: string, tenantId: string, userId: string, formId: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    createForm(projectId: string, tenantId: string, userId: string, dto: CreateLeadFormDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    updateForm(projectId: string, tenantId: string, userId: string, formId: string, dto: UpdateLeadFormDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    deleteForm(projectId: string, tenantId: string, userId: string, formId: string): Promise<void>;
    captureLead(projectId: string, dto: CaptureLeadDto, ip: string, userAgent: string): Promise<{
        success: boolean;
        leadId: string;
        redirectUrl: string | null;
    }>;
    captureWebhookLead(projectId: string, dto: WebhookLeadDto, ip: string, userAgent: string): Promise<{
        success: boolean;
        leadId: string;
        message: string;
    }>;
    processExternalLead(projectId: string, platform: LeadPlatform, leadData: {
        externalId: string;
        formId: string;
        formName: string;
        email?: string;
        name?: string;
        phone?: string;
        customFields?: Record<string, unknown>;
    }): Promise<{
        leadId: string;
    }>;
    getLeads(projectId: string, tenantId: string, userId: string, query: LeadQueryDto): Promise<{
        leads: {
            custom_fields: any;
            created_at: string;
            lead_id: string;
            project_id: string;
            platform: string;
            form_id: string;
            form_name: string;
            email: string;
            name: string;
            phone: string;
            utm_source: string;
            utm_medium: string;
            utm_campaign: string;
            referrer: string;
            page_url: string;
            ip: string;
            user_agent: string;
        }[];
        total: number;
        limit: number;
        offset: number;
    }>;
    getLeadStats(projectId: string, tenantId: string, userId: string, query: LeadQueryDto): Promise<{
        totalLeads: number;
        leadsToday: number;
        byPlatform: {
            platform: string;
            count: number;
        }[];
        byForm: {
            formId: string;
            formName: string;
            count: number;
        }[];
        timeline: {
            date: string;
            count: number;
        }[];
    }>;
    getNotificationConfigs(projectId: string, tenantId: string, userId: string): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
    createNotificationConfig(projectId: string, tenantId: string, userId: string, dto: CreateNotificationConfigDto): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }>;
    updateNotificationConfig(projectId: string, tenantId: string, userId: string, configId: string, dto: UpdateNotificationConfigDto): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }>;
    deleteNotificationConfig(projectId: string, tenantId: string, userId: string, configId: string): Promise<void>;
    private insertLeadToClickHouse;
    private sendLeadNotifications;
    private generateEmbedCode;
    checkProjectAccess(projectId: string, tenantId: string, userId: string, allowedRoles?: MemberRole[]): Promise<void>;
    private escape;
}
//# sourceMappingURL=leads.service.d.ts.map