"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MfaController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const passport_1 = require("@nestjs/passport");
const mfa_service_1 = require("./mfa.service");
const mfa_dto_1 = require("./dto/mfa.dto");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
let MfaController = class MfaController {
    mfaService;
    constructor(mfaService) {
        this.mfaService = mfaService;
    }
    async getMfaStatus(user) {
        return this.mfaService.getMfaStatus(user.sub);
    }
    async setupMfa(user) {
        return this.mfaService.setupMfa(user.sub);
    }
    async verifyAndEnableMfa(user, dto) {
        await this.mfaService.verifyAndEnableMfa(user.sub, dto.token);
        return {
            success: true,
            message: 'MFA enabled successfully',
        };
    }
    async disableMfa(user, dto) {
        await this.mfaService.disableMfa(user.sub, dto.token);
        return {
            success: true,
            message: 'MFA disabled successfully',
        };
    }
    async regenerateBackupCodes(user, dto) {
        const backupCodes = await this.mfaService.regenerateBackupCodes(user.sub, dto.token);
        return { backupCodes };
    }
};
exports.MfaController = MfaController;
__decorate([
    (0, common_1.Get)('status'),
    (0, swagger_1.ApiOperation)({ summary: 'Get MFA status for current user' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'MFA status',
        type: mfa_dto_1.MfaStatusResponseDto,
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MfaController.prototype, "getMfaStatus", null);
__decorate([
    (0, common_1.Post)('setup'),
    (0, swagger_1.ApiOperation)({ summary: 'Initialize MFA setup (generate secret and QR code)' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'MFA setup data (secret, QR code, backup codes)',
        type: mfa_dto_1.MfaSetupResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'MFA already enabled',
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MfaController.prototype, "setupMfa", null);
__decorate([
    (0, common_1.Post)('verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Verify TOTP code and enable MFA' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'MFA enabled successfully',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid verification code',
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mfa_dto_1.VerifyMfaDto]),
    __metadata("design:returntype", Promise)
], MfaController.prototype, "verifyAndEnableMfa", null);
__decorate([
    (0, common_1.Delete)('disable'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Disable MFA (requires current TOTP code)' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'MFA disabled successfully',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid verification code',
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mfa_dto_1.DisableMfaDto]),
    __metadata("design:returntype", Promise)
], MfaController.prototype, "disableMfa", null);
__decorate([
    (0, common_1.Post)('backup-codes/regenerate'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Regenerate backup codes (requires current TOTP code)' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'New backup codes',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid verification code',
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mfa_dto_1.RegenerateBackupCodesDto]),
    __metadata("design:returntype", Promise)
], MfaController.prototype, "regenerateBackupCodes", null);
exports.MfaController = MfaController = __decorate([
    (0, swagger_1.ApiTags)('auth'),
    (0, common_1.Controller)('auth/mfa'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [mfa_service_1.MfaService])
], MfaController);
//# sourceMappingURL=mfa.controller.js.map