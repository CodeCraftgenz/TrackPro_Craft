export declare class UsersModule {
}
//# sourceMappingURL=users.module.d.ts.map