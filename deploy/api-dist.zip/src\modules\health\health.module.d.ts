export declare class HealthModule {
}
//# sourceMappingURL=health.module.d.ts.map