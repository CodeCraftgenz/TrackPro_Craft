export declare class ClickHouseModule {
}
//# sourceMappingURL=clickhouse.module.d.ts.map