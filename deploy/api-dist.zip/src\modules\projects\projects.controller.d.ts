import { ProjectsService } from './projects.service';
import { ApiKeysService } from './api-keys.service';
import { CreateProjectDto, UpdateProjectDto, CreateApiKeyDto } from './dto/projects.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class ProjectsController {
    private readonly projectsService;
    private readonly apiKeysService;
    constructor(projectsService: ProjectsService, apiKeysService: ApiKeysService);
    create(user: JwtPayload, tenantId: string, dto: CreateProjectDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    findAll(user: JwtPayload, tenantId: string): Promise<({
        integrationMeta: {
            enabled: boolean;
            pixelId: string;
        } | null;
        _count: {
            apiKeys: number;
        };
    } & {
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    })[]>;
    findOne(user: JwtPayload, tenantId: string, id: string): Promise<{
        integrationMeta: {
            id: string;
            createdAt: Date;
            enabled: boolean;
            pixelId: string;
            testEventCode: string | null;
        } | null;
        apiKeys: {
            name: string;
            id: string;
            createdAt: Date;
            scopes: import("@prisma/client/runtime/library").JsonValue;
            keyPrefix: string;
            lastUsedAt: Date | null;
        }[];
    } & {
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    update(user: JwtPayload, tenantId: string, id: string, dto: UpdateProjectDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    delete(user: JwtPayload, tenantId: string, id: string): Promise<void>;
    createApiKey(user: JwtPayload, tenantId: string, projectId: string, dto: CreateApiKeyDto): Promise<import("./api-keys.service").GeneratedApiKey>;
    listApiKeys(user: JwtPayload, tenantId: string, projectId: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        scopes: import("@prisma/client/runtime/library").JsonValue;
        keyPrefix: string;
        lastUsedAt: Date | null;
    }[]>;
    revokeApiKey(user: JwtPayload, tenantId: string, projectId: string, keyId: string): Promise<void>;
    revealApiKey(user: JwtPayload, tenantId: string, projectId: string, keyId: string): Promise<{
        apiKey: string;
    }>;
}
//# sourceMappingURL=projects.controller.d.ts.map