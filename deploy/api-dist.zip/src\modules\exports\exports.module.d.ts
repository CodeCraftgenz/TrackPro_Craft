export declare class ExportsModule {
}
//# sourceMappingURL=exports.module.d.ts.map