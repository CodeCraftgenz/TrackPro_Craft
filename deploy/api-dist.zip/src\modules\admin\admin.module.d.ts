export declare class AdminModule {
}
//# sourceMappingURL=admin.module.d.ts.map