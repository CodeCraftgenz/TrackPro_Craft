import { ProjectStatus } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateProjectDto, UpdateProjectDto } from './dto/projects.dto';
export declare class ProjectsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(tenantId: string, userId: string, dto: CreateProjectDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    findAllForTenant(tenantId: string, userId: string): Promise<({
        integrationMeta: {
            enabled: boolean;
            pixelId: string;
        } | null;
        _count: {
            apiKeys: number;
        };
    } & {
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    })[]>;
    findById(projectId: string, tenantId: string, userId: string): Promise<{
        integrationMeta: {
            id: string;
            createdAt: Date;
            enabled: boolean;
            pixelId: string;
            testEventCode: string | null;
        } | null;
        apiKeys: {
            name: string;
            id: string;
            createdAt: Date;
            scopes: import("@prisma/client/runtime/library").JsonValue;
            keyPrefix: string;
            lastUsedAt: Date | null;
        }[];
    } & {
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    update(projectId: string, tenantId: string, userId: string, dto: UpdateProjectDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    delete(projectId: string, tenantId: string, userId: string): Promise<void>;
    updateStatus(projectId: string, tenantId: string, userId: string, status: ProjectStatus): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        tenantId: string;
        status: import("@prisma/client").$Enums.ProjectStatus;
        domain: string;
        timezone: string;
        retentionDays: number;
    }>;
    private checkTenantAccess;
}
//# sourceMappingURL=projects.service.d.ts.map