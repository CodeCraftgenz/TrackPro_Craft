"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var LeadsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LeadsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_1 = require("@prisma/client");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../integrations/encryption.service");
const clickhouse_service_1 = require("../analytics/clickhouse.service");
let LeadsService = LeadsService_1 = class LeadsService {
    prisma;
    encryption;
    clickhouse;
    configService;
    logger = new common_1.Logger(LeadsService_1.name);
    constructor(prisma, encryption, clickhouse, configService) {
        this.prisma = prisma;
        this.encryption = encryption;
        this.clickhouse = clickhouse;
        this.configService = configService;
    }
    async getIntegrations(projectId, tenantId, userId) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        const integrations = await this.prisma.leadIntegration.findMany({
            where: { projectId },
        });
        return integrations.map((integration) => ({
            id: integration.id,
            platform: integration.platform,
            status: integration.status,
            pageId: integration.pageId,
            pageName: integration.pageName,
            formIds: integration.formIds,
            hasAccessToken: !!integration.accessTokenEncrypted,
            lastSyncAt: integration.lastSyncAt,
            errorMessage: integration.errorMessage,
            createdAt: integration.createdAt,
            updatedAt: integration.updatedAt,
        }));
    }
    async getIntegration(projectId, tenantId, userId, platform) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        const integration = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform,
                },
            },
        });
        if (!integration) {
            return null;
        }
        return {
            id: integration.id,
            platform: integration.platform,
            status: integration.status,
            pageId: integration.pageId,
            pageName: integration.pageName,
            formIds: integration.formIds,
            hasAccessToken: !!integration.accessTokenEncrypted,
            lastSyncAt: integration.lastSyncAt,
            errorMessage: integration.errorMessage,
            metadata: integration.metadata,
            createdAt: integration.createdAt,
            updatedAt: integration.updatedAt,
        };
    }
    async createIntegration(projectId, tenantId, userId, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        const existing = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform: dto.platform,
                },
            },
        });
        if (existing) {
            throw new common_1.ConflictException(`Integration for ${dto.platform} already exists`);
        }
        const webhookSecret = (0, crypto_1.randomBytes)(32).toString('hex');
        const integration = await this.prisma.leadIntegration.create({
            data: {
                projectId,
                platform: dto.platform,
                status: dto.accessToken ? client_1.LeadIntegrationStatus.ACTIVE : client_1.LeadIntegrationStatus.PENDING,
                accessTokenEncrypted: dto.accessToken
                    ? this.encryption.encrypt(dto.accessToken)
                    : null,
                refreshTokenEncrypted: dto.refreshToken
                    ? this.encryption.encrypt(dto.refreshToken)
                    : null,
                pageId: dto.pageId,
                pageName: dto.pageName,
                formIds: dto.formIds || [],
                webhookSecret,
            },
        });
        this.logger.log(`Lead integration created: ${dto.platform} for project ${projectId}`);
        return {
            id: integration.id,
            platform: integration.platform,
            status: integration.status,
            pageId: integration.pageId,
            pageName: integration.pageName,
            formIds: integration.formIds,
            webhookSecret: integration.webhookSecret,
            hasAccessToken: !!integration.accessTokenEncrypted,
            createdAt: integration.createdAt,
        };
    }
    async updateIntegration(projectId, tenantId, userId, platform, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        const existing = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform,
                },
            },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Integration not found');
        }
        const updateData = {};
        if (dto.accessToken !== undefined) {
            updateData.accessTokenEncrypted = this.encryption.encrypt(dto.accessToken);
            updateData.status = client_1.LeadIntegrationStatus.ACTIVE;
            updateData.errorMessage = null;
        }
        if (dto.refreshToken !== undefined) {
            updateData.refreshTokenEncrypted = this.encryption.encrypt(dto.refreshToken);
        }
        if (dto.pageId !== undefined)
            updateData.pageId = dto.pageId;
        if (dto.pageName !== undefined)
            updateData.pageName = dto.pageName;
        if (dto.formIds !== undefined)
            updateData.formIds = dto.formIds;
        if (dto.enabled !== undefined) {
            updateData.status = dto.enabled
                ? client_1.LeadIntegrationStatus.ACTIVE
                : client_1.LeadIntegrationStatus.INACTIVE;
        }
        const integration = await this.prisma.leadIntegration.update({
            where: {
                projectId_platform: {
                    projectId,
                    platform,
                },
            },
            data: updateData,
        });
        return {
            id: integration.id,
            platform: integration.platform,
            status: integration.status,
            pageId: integration.pageId,
            pageName: integration.pageName,
            formIds: integration.formIds,
            hasAccessToken: !!integration.accessTokenEncrypted,
            updatedAt: integration.updatedAt,
        };
    }
    async deleteIntegration(projectId, tenantId, userId, platform) {
        await this.checkProjectAccess(projectId, tenantId, userId, [client_1.MemberRole.OWNER]);
        const existing = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform,
                },
            },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Integration not found');
        }
        await this.prisma.leadIntegration.delete({
            where: {
                projectId_platform: {
                    projectId,
                    platform,
                },
            },
        });
        this.logger.log(`Lead integration deleted: ${platform} for project ${projectId}`);
    }
    async getForms(projectId, tenantId, userId) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        return this.prisma.leadFormConfig.findMany({
            where: { projectId },
            orderBy: { createdAt: 'desc' },
        });
    }
    async getForm(projectId, tenantId, userId, formId) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        const form = await this.prisma.leadFormConfig.findFirst({
            where: { id: formId, projectId },
        });
        if (!form) {
            throw new common_1.NotFoundException('Form not found');
        }
        return form;
    }
    async createForm(projectId, tenantId, userId, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        const apiUrl = this.configService.get('API_URL', 'http://localhost:3001');
        const formId = `form_${(0, crypto_1.randomBytes)(8).toString('hex')}`;
        const embedCode = this.generateEmbedCode(apiUrl, projectId, formId, dto);
        const form = await this.prisma.leadFormConfig.create({
            data: {
                id: formId,
                projectId,
                name: dto.name,
                fields: JSON.parse(JSON.stringify(dto.fields)),
                styling: dto.styling ? JSON.parse(JSON.stringify(dto.styling)) : {},
                redirectUrl: dto.redirectUrl,
                embedCode,
            },
        });
        this.logger.log(`Lead form created: ${form.name} for project ${projectId}`);
        return form;
    }
    async updateForm(projectId, tenantId, userId, formId, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        const existing = await this.prisma.leadFormConfig.findFirst({
            where: { id: formId, projectId },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Form not found');
        }
        const updateData = {};
        if (dto.name !== undefined)
            updateData.name = dto.name;
        if (dto.fields !== undefined)
            updateData.fields = dto.fields;
        if (dto.styling !== undefined)
            updateData.styling = dto.styling;
        if (dto.redirectUrl !== undefined)
            updateData.redirectUrl = dto.redirectUrl;
        if (dto.enabled !== undefined)
            updateData.enabled = dto.enabled;
        if (dto.fields !== undefined) {
            const apiUrl = this.configService.get('API_URL', 'http://localhost:3001');
            updateData.embedCode = this.generateEmbedCode(apiUrl, projectId, formId, {
                name: dto.name || existing.name,
                fields: dto.fields,
                styling: dto.styling || existing.styling,
                redirectUrl: dto.redirectUrl || existing.redirectUrl || undefined,
            });
        }
        return this.prisma.leadFormConfig.update({
            where: { id: formId },
            data: updateData,
        });
    }
    async deleteForm(projectId, tenantId, userId, formId) {
        await this.checkProjectAccess(projectId, tenantId, userId, [client_1.MemberRole.OWNER]);
        const existing = await this.prisma.leadFormConfig.findFirst({
            where: { id: formId, projectId },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Form not found');
        }
        await this.prisma.leadFormConfig.delete({
            where: { id: formId },
        });
        this.logger.log(`Lead form deleted: ${formId} for project ${projectId}`);
    }
    async captureLead(projectId, dto, ip, userAgent) {
        const form = await this.prisma.leadFormConfig.findFirst({
            where: { id: dto.formId, projectId, enabled: true },
        });
        if (!form) {
            throw new common_1.BadRequestException('Form not found or disabled');
        }
        const email = dto.data.email || '';
        const name = dto.data.name || '';
        const phone = dto.data.phone || '';
        const customFields = { ...dto.data };
        delete customFields.email;
        delete customFields.name;
        delete customFields.phone;
        const leadId = `lead_${Date.now()}_${(0, crypto_1.randomBytes)(4).toString('hex')}`;
        await this.insertLeadToClickHouse({
            lead_id: leadId,
            project_id: projectId,
            platform: 'WEBSITE',
            form_id: dto.formId,
            form_name: form.name,
            email,
            name,
            phone,
            custom_fields: JSON.stringify(customFields),
            utm_source: dto.utm_source || '',
            utm_medium: dto.utm_medium || '',
            utm_campaign: dto.utm_campaign || '',
            referrer: dto.referrer || '',
            page_url: dto.page_url || '',
            ip,
            user_agent: userAgent,
            created_at: Math.floor(Date.now() / 1000),
        });
        await this.sendLeadNotifications(projectId, 'WEBSITE', {
            leadId,
            formName: form.name,
            email,
            name,
            phone,
            customFields,
        });
        this.logger.log(`Lead captured: ${leadId} from form ${dto.formId}`);
        return {
            success: true,
            leadId,
            redirectUrl: form.redirectUrl,
        };
    }
    async captureWebhookLead(projectId, dto, ip, userAgent) {
        const leadId = `lead_webhook_${Date.now()}_${(0, crypto_1.randomBytes)(4).toString('hex')}`;
        await this.insertLeadToClickHouse({
            lead_id: leadId,
            project_id: projectId,
            platform: 'WEBSITE',
            form_id: 'webhook',
            form_name: 'API Webhook',
            email: dto.email || '',
            name: dto.name || '',
            phone: dto.phone || '',
            custom_fields: JSON.stringify(dto.custom || {}),
            utm_source: dto.utm_source || '',
            utm_medium: dto.utm_medium || '',
            utm_campaign: dto.utm_campaign || '',
            referrer: dto.referrer || '',
            page_url: dto.page_url || '',
            ip,
            user_agent: userAgent,
            created_at: Math.floor(Date.now() / 1000),
        });
        await this.sendLeadNotifications(projectId, 'WEBSITE', {
            leadId,
            formName: 'API Webhook',
            email: dto.email || '',
            name: dto.name || '',
            phone: dto.phone || '',
            customFields: dto.custom || {},
        });
        this.logger.log(`Webhook lead captured: ${leadId} for project ${projectId}`);
        return {
            success: true,
            leadId,
            message: 'Lead captured successfully',
        };
    }
    async processExternalLead(projectId, platform, leadData) {
        const leadId = `lead_${platform.toLowerCase()}_${leadData.externalId}`;
        await this.insertLeadToClickHouse({
            lead_id: leadId,
            project_id: projectId,
            platform,
            form_id: leadData.formId,
            form_name: leadData.formName,
            email: leadData.email || '',
            name: leadData.name || '',
            phone: leadData.phone || '',
            custom_fields: JSON.stringify(leadData.customFields || {}),
            utm_source: '',
            utm_medium: '',
            utm_campaign: '',
            referrer: '',
            page_url: '',
            ip: '',
            user_agent: '',
            created_at: Math.floor(Date.now() / 1000),
        });
        await this.sendLeadNotifications(projectId, platform, {
            leadId,
            formName: leadData.formName,
            email: leadData.email || '',
            name: leadData.name || '',
            phone: leadData.phone || '',
            customFields: leadData.customFields || {},
        });
        this.logger.log(`External lead processed: ${leadId} from ${platform}`);
        return { leadId };
    }
    async getLeads(projectId, tenantId, userId, query) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        const { limit = 50, offset = 0, platform, formId, startDate, endDate } = query;
        const conditions = [`project_id = '${this.escape(projectId)}'`];
        if (platform) {
            conditions.push(`platform = '${this.escape(platform)}'`);
        }
        if (formId) {
            conditions.push(`form_id = '${this.escape(formId)}'`);
        }
        if (startDate) {
            const startTimestamp = Math.floor(new Date(startDate).getTime() / 1000);
            conditions.push(`created_at >= ${startTimestamp}`);
        }
        if (endDate) {
            const endTimestamp = Math.floor(new Date(endDate).getTime() / 1000);
            conditions.push(`created_at <= ${endTimestamp}`);
        }
        const where = conditions.join(' AND ');
        try {
            const countSql = `SELECT count() as total FROM events_leads WHERE ${where}`;
            const countResult = await this.clickhouse.queryRows(countSql);
            const total = parseInt(countResult[0]?.total || '0', 10);
            const leadsSql = `
        SELECT
          lead_id,
          project_id,
          platform,
          form_id,
          form_name,
          email,
          name,
          phone,
          custom_fields,
          utm_source,
          utm_medium,
          utm_campaign,
          referrer,
          page_url,
          created_at
        FROM events_leads
        WHERE ${where}
        ORDER BY created_at DESC
        LIMIT ${limit}
        OFFSET ${offset}
      `;
            const leads = await this.clickhouse.queryRows(leadsSql);
            return {
                leads: leads.map((lead) => ({
                    ...lead,
                    custom_fields: JSON.parse(lead.custom_fields || '{}'),
                    created_at: new Date(lead.created_at * 1000).toISOString(),
                })),
                total,
                limit,
                offset,
            };
        }
        catch {
            return { leads: [], total: 0, limit, offset };
        }
    }
    async getLeadStats(projectId, tenantId, userId, query) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        const { startDate, endDate } = query;
        const conditions = [`project_id = '${this.escape(projectId)}'`];
        if (startDate) {
            const startTimestamp = Math.floor(new Date(startDate).getTime() / 1000);
            conditions.push(`created_at >= ${startTimestamp}`);
        }
        if (endDate) {
            const endTimestamp = Math.floor(new Date(endDate).getTime() / 1000);
            conditions.push(`created_at <= ${endTimestamp}`);
        }
        const where = conditions.join(' AND ');
        try {
            const totalSql = `SELECT count() as total FROM events_leads WHERE ${where}`;
            const totalResult = await this.clickhouse.queryRows(totalSql);
            const totalLeads = parseInt(totalResult[0]?.total || '0', 10);
            const platformSql = `
        SELECT platform, count() as count
        FROM events_leads
        WHERE ${where}
        GROUP BY platform
        ORDER BY count DESC
      `;
            const platformResult = await this.clickhouse.queryRows(platformSql);
            const formSql = `
        SELECT form_id, form_name, count() as count
        FROM events_leads
        WHERE ${where}
        GROUP BY form_id, form_name
        ORDER BY count DESC
        LIMIT 10
      `;
            const formResult = await this.clickhouse.queryRows(formSql);
            const timelineSql = `
        SELECT
          toDate(toDateTime(created_at)) as date,
          count() as count
        FROM events_leads
        WHERE ${where}
        GROUP BY date
        ORDER BY date DESC
        LIMIT 30
      `;
            const timelineResult = await this.clickhouse.queryRows(timelineSql);
            const now = Math.floor(Date.now() / 1000);
            const todayStart = now - (now % 86400);
            const todaySql = `
        SELECT count() as total
        FROM events_leads
        WHERE project_id = '${this.escape(projectId)}' AND created_at >= ${todayStart}
      `;
            const todayResult = await this.clickhouse.queryRows(todaySql);
            const leadsToday = parseInt(todayResult[0]?.total || '0', 10);
            return {
                totalLeads,
                leadsToday,
                byPlatform: platformResult.map((row) => ({
                    platform: row.platform,
                    count: parseInt(row.count, 10),
                })),
                byForm: formResult.map((row) => ({
                    formId: row.form_id,
                    formName: row.form_name,
                    count: parseInt(row.count, 10),
                })),
                timeline: timelineResult.map((row) => ({
                    date: row.date,
                    count: parseInt(row.count, 10),
                })),
            };
        }
        catch {
            return {
                totalLeads: 0,
                leadsToday: 0,
                byPlatform: [],
                byForm: [],
                timeline: [],
            };
        }
    }
    async getNotificationConfigs(projectId, tenantId, userId) {
        await this.checkProjectAccess(projectId, tenantId, userId);
        return this.prisma.leadNotificationConfig.findMany({
            where: { projectId },
        });
    }
    async createNotificationConfig(projectId, tenantId, userId, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        return this.prisma.leadNotificationConfig.create({
            data: {
                projectId,
                email: dto.email,
                webhookUrl: dto.webhookUrl,
                platforms: dto.platforms,
            },
        });
    }
    async updateNotificationConfig(projectId, tenantId, userId, configId, dto) {
        await this.checkProjectAccess(projectId, tenantId, userId, [
            client_1.MemberRole.OWNER,
            client_1.MemberRole.ADMIN,
        ]);
        const existing = await this.prisma.leadNotificationConfig.findFirst({
            where: { id: configId, projectId },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Notification config not found');
        }
        return this.prisma.leadNotificationConfig.update({
            where: { id: configId },
            data: dto,
        });
    }
    async deleteNotificationConfig(projectId, tenantId, userId, configId) {
        await this.checkProjectAccess(projectId, tenantId, userId, [client_1.MemberRole.OWNER]);
        const existing = await this.prisma.leadNotificationConfig.findFirst({
            where: { id: configId, projectId },
        });
        if (!existing) {
            throw new common_1.NotFoundException('Notification config not found');
        }
        await this.prisma.leadNotificationConfig.delete({
            where: { id: configId },
        });
    }
    async insertLeadToClickHouse(lead) {
        const sql = `
      INSERT INTO events_leads (
        lead_id, project_id, platform, form_id, form_name,
        email, name, phone, custom_fields,
        utm_source, utm_medium, utm_campaign,
        referrer, page_url, ip, user_agent, created_at
      ) VALUES (
        '${this.escape(lead.lead_id)}',
        '${this.escape(lead.project_id)}',
        '${this.escape(lead.platform)}',
        '${this.escape(lead.form_id)}',
        '${this.escape(lead.form_name)}',
        '${this.escape(lead.email)}',
        '${this.escape(lead.name)}',
        '${this.escape(lead.phone)}',
        '${this.escape(lead.custom_fields)}',
        '${this.escape(lead.utm_source)}',
        '${this.escape(lead.utm_medium)}',
        '${this.escape(lead.utm_campaign)}',
        '${this.escape(lead.referrer)}',
        '${this.escape(lead.page_url)}',
        '${this.escape(lead.ip)}',
        '${this.escape(lead.user_agent)}',
        ${lead.created_at}
      )
    `;
        await this.clickhouse.queryRows(sql);
    }
    async sendLeadNotifications(projectId, platform, leadData) {
        const configs = await this.prisma.leadNotificationConfig.findMany({
            where: {
                projectId,
                enabled: true,
            },
        });
        for (const config of configs) {
            const platforms = config.platforms;
            if (!platforms.includes(platform))
                continue;
            if (config.webhookUrl) {
                try {
                    await fetch(config.webhookUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            event: 'lead.created',
                            platform,
                            ...leadData,
                            timestamp: new Date().toISOString(),
                        }),
                    });
                }
                catch (error) {
                    this.logger.error(`Failed to send webhook notification: ${error}`);
                }
            }
            if (config.email) {
                this.logger.log(`Email notification would be sent to ${config.email} for lead ${leadData.leadId}`);
            }
        }
    }
    generateEmbedCode(apiUrl, projectId, formId, dto) {
        const styling = dto.styling || {};
        return `<!-- ZtackPro Lead Capture Form -->
<div id="ztackpro-form-${formId}"></div>
<script>
(function() {
  var formConfig = ${JSON.stringify({
            formId,
            projectId,
            apiUrl: `${apiUrl}/api/v1/public/leads/capture`,
            fields: dto.fields,
            styling: {
                primaryColor: styling.primaryColor || '#00E4F2',
                backgroundColor: styling.backgroundColor || '#ffffff',
                textColor: styling.textColor || '#333333',
                buttonText: styling.buttonText || 'Enviar',
                successMessage: styling.successMessage || 'Obrigado! Entraremos em contato.',
            },
            redirectUrl: dto.redirectUrl,
        })};

  function createForm() {
    var container = document.getElementById('ztackpro-form-' + formConfig.formId);
    if (!container) return;

    var form = document.createElement('form');
    form.style.cssText = 'font-family: system-ui, sans-serif; max-width: 400px; padding: 20px; background: ' + formConfig.styling.backgroundColor + '; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);';

    formConfig.fields.forEach(function(field) {
      var wrapper = document.createElement('div');
      wrapper.style.marginBottom = '16px';

      var label = document.createElement('label');
      label.textContent = field.label + (field.required ? ' *' : '');
      label.style.cssText = 'display: block; margin-bottom: 4px; font-weight: 500; color: ' + formConfig.styling.textColor + ';';

      var input;
      if (field.type === 'textarea') {
        input = document.createElement('textarea');
        input.rows = 3;
      } else if (field.type === 'select' && field.options) {
        input = document.createElement('select');
        field.options.forEach(function(opt) {
          var option = document.createElement('option');
          option.value = opt;
          option.textContent = opt;
          input.appendChild(option);
        });
      } else {
        input = document.createElement('input');
        input.type = field.type === 'phone' ? 'tel' : field.type;
      }

      input.name = field.name;
      input.required = field.required;
      input.style.cssText = 'width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box;';

      wrapper.appendChild(label);
      wrapper.appendChild(input);
      form.appendChild(wrapper);
    });

    var button = document.createElement('button');
    button.type = 'submit';
    button.textContent = formConfig.styling.buttonText;
    button.style.cssText = 'width: 100%; padding: 12px; background: ' + formConfig.styling.primaryColor + '; color: white; border: none; border-radius: 4px; font-size: 16px; font-weight: 600; cursor: pointer;';
    form.appendChild(button);

    var message = document.createElement('div');
    message.id = 'ztackpro-message-' + formConfig.formId;
    message.style.cssText = 'display: none; margin-top: 16px; padding: 12px; border-radius: 4px; text-align: center;';
    form.appendChild(message);

    form.onsubmit = function(e) {
      e.preventDefault();
      button.disabled = true;
      button.textContent = 'Enviando...';

      var data = {};
      formConfig.fields.forEach(function(field) {
        data[field.name] = form[field.name].value;
      });

      fetch(formConfig.apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          formId: formConfig.formId,
          data: data,
          source: 'embed',
          referrer: document.referrer,
          page_url: window.location.href,
          utm_source: new URLSearchParams(window.location.search).get('utm_source') || '',
          utm_medium: new URLSearchParams(window.location.search).get('utm_medium') || '',
          utm_campaign: new URLSearchParams(window.location.search).get('utm_campaign') || ''
        })
      })
      .then(function(res) { return res.json(); })
      .then(function(result) {
        if (result.success) {
          message.textContent = formConfig.styling.successMessage;
          message.style.display = 'block';
          message.style.background = '#d4edda';
          message.style.color = '#155724';
          form.reset();
          if (result.redirectUrl) {
            setTimeout(function() { window.location.href = result.redirectUrl; }, 2000);
          }
        } else {
          message.textContent = 'Erro ao enviar. Tente novamente.';
          message.style.display = 'block';
          message.style.background = '#f8d7da';
          message.style.color = '#721c24';
        }
      })
      .catch(function() {
        message.textContent = 'Erro ao enviar. Tente novamente.';
        message.style.display = 'block';
        message.style.background = '#f8d7da';
        message.style.color = '#721c24';
      })
      .finally(function() {
        button.disabled = false;
        button.textContent = formConfig.styling.buttonText;
      });
    };

    container.appendChild(form);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createForm);
  } else {
    createForm();
  }
})();
</script>`;
    }
    async checkProjectAccess(projectId, tenantId, userId, allowedRoles) {
        const project = await this.prisma.project.findFirst({
            where: { id: projectId, tenantId },
        });
        if (!project) {
            throw new common_1.NotFoundException('Project not found');
        }
        const membership = await this.prisma.membership.findUnique({
            where: {
                userId_tenantId: {
                    userId,
                    tenantId,
                },
            },
        });
        if (!membership) {
            throw new common_1.ForbiddenException('Access denied');
        }
        if (allowedRoles && !allowedRoles.includes(membership.role)) {
            throw new common_1.ForbiddenException('Insufficient permissions');
        }
    }
    escape(value) {
        if (value === null || value === undefined) {
            return '';
        }
        return String(value).replace(/'/g, "\\'").replace(/\\/g, '\\\\');
    }
};
exports.LeadsService = LeadsService;
exports.LeadsService = LeadsService = LeadsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService,
        clickhouse_service_1.ClickHouseService,
        config_1.ConfigService])
], LeadsService);
//# sourceMappingURL=leads.service.js.map