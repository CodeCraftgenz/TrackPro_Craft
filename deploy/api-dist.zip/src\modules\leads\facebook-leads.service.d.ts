import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../integrations/encryption.service';
import { LeadsService } from './leads.service';
export interface FacebookPage {
    id: string;
    name: string;
    access_token: string;
}
export interface FacebookForm {
    id: string;
    name: string;
    status: string;
    locale: string;
}
interface FacebookLead {
    id: string;
    created_time: string;
    field_data: Array<{
        name: string;
        values: string[];
    }>;
}
export declare class FacebookLeadsService {
    private readonly prisma;
    private readonly encryption;
    private readonly configService;
    private readonly leadsService;
    private readonly logger;
    private readonly graphApiUrl;
    constructor(prisma: PrismaService, encryption: EncryptionService, configService: ConfigService, leadsService: LeadsService);
    getOAuthUrl(projectId: string, tenantId: string): string;
    exchangeCodeForToken(code: string): Promise<{
        accessToken: string;
        expiresIn: number;
    }>;
    getPages(accessToken: string): Promise<FacebookPage[]>;
    getLeadForms(pageId: string, pageAccessToken: string): Promise<FacebookForm[]>;
    getLeadsFromForm(formId: string, pageAccessToken: string, since?: number): Promise<FacebookLead[]>;
    subscribeToLeadgenWebhook(pageId: string, pageAccessToken: string): Promise<boolean>;
    processWebhook(entry: {
        id: string;
        time: number;
        changes: Array<{
            field: string;
            value: {
                form_id: string;
                leadgen_id: string;
                page_id: string;
                created_time: number;
            };
        }>;
    }[]): Promise<void>;
    syncLeads(projectId: string): Promise<{
        synced: number;
        errors: number;
    }>;
}
export {};
//# sourceMappingURL=facebook-leads.service.d.ts.map