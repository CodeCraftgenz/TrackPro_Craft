"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanComparisonResponseDto = exports.PlanLimitCheckResponseDto = exports.CheckoutSessionResponseDto = exports.InvoiceResponseDto = exports.UsageSummaryResponseDto = exports.SubscriptionResponseDto = exports.PlanResponseDto = exports.UpdateStripePriceIdsDto = exports.CreatePortalSessionDto = exports.CreateCheckoutSessionDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const client_1 = require("@prisma/client");
class CreateCheckoutSessionDto {
    planTier;
    billingInterval;
    successUrl;
    cancelUrl;
}
exports.CreateCheckoutSessionDto = CreateCheckoutSessionDto;
__decorate([
    (0, swagger_1.ApiProperty)({ enum: client_1.PlanTier, description: 'The plan tier to subscribe to' }),
    (0, class_validator_1.IsEnum)(client_1.PlanTier),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCheckoutSessionDto.prototype, "planTier", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: ['monthly', 'yearly'], description: 'Billing interval' }),
    (0, class_validator_1.IsEnum)(['monthly', 'yearly']),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCheckoutSessionDto.prototype, "billingInterval", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'URL to redirect to after successful checkout' }),
    (0, class_validator_1.IsUrl)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCheckoutSessionDto.prototype, "successUrl", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'URL to redirect to if checkout is canceled' }),
    (0, class_validator_1.IsUrl)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateCheckoutSessionDto.prototype, "cancelUrl", void 0);
class CreatePortalSessionDto {
    returnUrl;
}
exports.CreatePortalSessionDto = CreatePortalSessionDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'URL to redirect to after leaving the portal' }),
    (0, class_validator_1.IsUrl)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreatePortalSessionDto.prototype, "returnUrl", void 0);
class UpdateStripePriceIdsDto {
    tier;
    monthlyPriceId;
    yearlyPriceId;
}
exports.UpdateStripePriceIdsDto = UpdateStripePriceIdsDto;
__decorate([
    (0, swagger_1.ApiProperty)({ enum: client_1.PlanTier, description: 'The plan tier to update' }),
    (0, class_validator_1.IsEnum)(client_1.PlanTier),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], UpdateStripePriceIdsDto.prototype, "tier", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Stripe price ID for monthly billing' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], UpdateStripePriceIdsDto.prototype, "monthlyPriceId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Stripe price ID for yearly billing' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], UpdateStripePriceIdsDto.prototype, "yearlyPriceId", void 0);
class PlanResponseDto {
    id;
    name;
    tier;
    description;
    monthlyPrice;
    yearlyPrice;
    maxProjects;
    maxEventsPerMonth;
    maxTeamMembers;
    retentionDays;
    features;
}
exports.PlanResponseDto = PlanResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], PlanResponseDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], PlanResponseDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: client_1.PlanTier }),
    __metadata("design:type", String)
], PlanResponseDto.prototype, "tier", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], PlanResponseDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Monthly price in cents' }),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "monthlyPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Yearly price in cents' }),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "yearlyPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "maxProjects", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "maxEventsPerMonth", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "maxTeamMembers", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], PlanResponseDto.prototype, "retentionDays", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [String] }),
    __metadata("design:type", Array)
], PlanResponseDto.prototype, "features", void 0);
class SubscriptionResponseDto {
    id;
    status;
    plan;
    billingInterval;
    currentPeriodStart;
    currentPeriodEnd;
    cancelAtPeriodEnd;
    trialEnd;
}
exports.SubscriptionResponseDto = SubscriptionResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], SubscriptionResponseDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], SubscriptionResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Object)
], SubscriptionResponseDto.prototype, "plan", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], SubscriptionResponseDto.prototype, "billingInterval", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", Date)
], SubscriptionResponseDto.prototype, "currentPeriodStart", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", Date)
], SubscriptionResponseDto.prototype, "currentPeriodEnd", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Boolean)
], SubscriptionResponseDto.prototype, "cancelAtPeriodEnd", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", Date)
], SubscriptionResponseDto.prototype, "trialEnd", void 0);
class UsageSummaryResponseDto {
    eventsCount;
    eventsLimit;
    eventsPercentage;
    projectsCount;
    projectsLimit;
    teamMembersCount;
    teamMembersLimit;
}
exports.UsageSummaryResponseDto = UsageSummaryResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "eventsCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "eventsLimit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Percentage of events used (0-100)' }),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "eventsPercentage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "projectsCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "projectsLimit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "teamMembersCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UsageSummaryResponseDto.prototype, "teamMembersLimit", void 0);
class InvoiceResponseDto {
    id;
    amountDue;
    amountPaid;
    currency;
    status;
    invoiceUrl;
    invoicePdf;
    periodStart;
    periodEnd;
    paidAt;
    createdAt;
}
exports.InvoiceResponseDto = InvoiceResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], InvoiceResponseDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Amount due in cents' }),
    __metadata("design:type", Number)
], InvoiceResponseDto.prototype, "amountDue", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Amount paid in cents' }),
    __metadata("design:type", Number)
], InvoiceResponseDto.prototype, "amountPaid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], InvoiceResponseDto.prototype, "currency", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], InvoiceResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], InvoiceResponseDto.prototype, "invoiceUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", String)
], InvoiceResponseDto.prototype, "invoicePdf", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Date)
], InvoiceResponseDto.prototype, "periodStart", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Date)
], InvoiceResponseDto.prototype, "periodEnd", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    __metadata("design:type", Date)
], InvoiceResponseDto.prototype, "paidAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Date)
], InvoiceResponseDto.prototype, "createdAt", void 0);
class CheckoutSessionResponseDto {
    url;
}
exports.CheckoutSessionResponseDto = CheckoutSessionResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'URL to redirect the user to for checkout' }),
    __metadata("design:type", String)
], CheckoutSessionResponseDto.prototype, "url", void 0);
class PlanLimitCheckResponseDto {
    allowed;
    current;
    limit;
}
exports.PlanLimitCheckResponseDto = PlanLimitCheckResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Whether the action is allowed' }),
    __metadata("design:type", Boolean)
], PlanLimitCheckResponseDto.prototype, "allowed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Current usage count' }),
    __metadata("design:type", Number)
], PlanLimitCheckResponseDto.prototype, "current", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Plan limit' }),
    __metadata("design:type", Number)
], PlanLimitCheckResponseDto.prototype, "limit", void 0);
class PlanComparisonResponseDto {
    plans;
    features;
}
exports.PlanComparisonResponseDto = PlanComparisonResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ type: [Object] }),
    __metadata("design:type", Array)
], PlanComparisonResponseDto.prototype, "plans", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [Object] }),
    __metadata("design:type", Array)
], PlanComparisonResponseDto.prototype, "features", void 0);
//# sourceMappingURL=billing.dto.js.map