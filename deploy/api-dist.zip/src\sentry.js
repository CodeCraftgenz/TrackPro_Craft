"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sentry = void 0;
exports.initSentry = initSentry;
const Sentry = __importStar(require("@sentry/nestjs"));
exports.Sentry = Sentry;
const profiling_node_1 = require("@sentry/profiling-node");
function initSentry() {
    const dsn = process.env.SENTRY_DSN;
    const environment = process.env.NODE_ENV || 'development';
    if (!dsn) {
        console.log('[Sentry] DSN not configured, error tracking disabled');
        return;
    }
    Sentry.init({
        dsn,
        environment,
        integrations: [(0, profiling_node_1.nodeProfilingIntegration)()],
        tracesSampleRate: environment === 'production' ? 0.1 : 1.0,
        profilesSampleRate: environment === 'production' ? 0.1 : 1.0,
        release: process.env.SENTRY_RELEASE || `trackpro-api@${process.env.npm_package_version || '0.0.0'}`,
        beforeSend(event) {
            if (event.request?.headers) {
                delete event.request.headers['authorization'];
                delete event.request.headers['cookie'];
                delete event.request.headers['x-api-key'];
            }
            if (event.request?.data) {
                const data = event.request.data;
                if (typeof data === 'object' && data !== null) {
                    const sanitized = { ...data };
                    const sensitiveFields = [
                        'password',
                        'passwordHash',
                        'token',
                        'refreshToken',
                        'accessToken',
                        'apiKey',
                        'secret',
                        'credential',
                    ];
                    for (const field of sensitiveFields) {
                        if (field in sanitized) {
                            sanitized[field] = '[REDACTED]';
                        }
                    }
                    event.request.data = sanitized;
                }
            }
            return event;
        },
        ignoreErrors: [
            'BadRequestException',
            'UnauthorizedException',
            'ForbiddenException',
            'NotFoundException',
            'ECONNRESET',
            'EPIPE',
            'ThrottlerException',
        ],
    });
    console.log(`[Sentry] Initialized for ${environment} environment`);
}
//# sourceMappingURL=sentry.js.map