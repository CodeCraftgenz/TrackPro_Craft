export declare class AnalyticsModule {
}
//# sourceMappingURL=analytics.module.d.ts.map