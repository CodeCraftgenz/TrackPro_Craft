export declare class RedisModule {
}
//# sourceMappingURL=redis.module.d.ts.map