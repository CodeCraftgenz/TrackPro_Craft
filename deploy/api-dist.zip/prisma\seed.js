"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const bcrypt = __importStar(require("bcryptjs"));
const prisma = new client_1.PrismaClient();
async function seedPlans() {
    console.log('Seeding billing plans...');
    const plans = [
        {
            tier: client_1.PlanTier.FREE,
            name: 'Free',
            description: 'Get started with basic analytics',
            monthlyPrice: 0,
            yearlyPrice: 0,
            maxProjects: 1,
            maxEventsPerMonth: 10000,
            maxTeamMembers: 1,
            retentionDays: 30,
            features: [
                'basic_analytics',
                'single_project',
                '30_day_retention',
                'community_support',
            ],
        },
        {
            tier: client_1.PlanTier.STARTER,
            name: 'Starter',
            description: 'For small teams getting serious about analytics',
            monthlyPrice: 2900,
            yearlyPrice: 29000,
            maxProjects: 3,
            maxEventsPerMonth: 100000,
            maxTeamMembers: 5,
            retentionDays: 90,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'multiple_projects',
                '90_day_retention',
                'email_support',
                'api_access',
                'csv_export',
            ],
        },
        {
            tier: client_1.PlanTier.PROFESSIONAL,
            name: 'Professional',
            description: 'For growing businesses with advanced needs',
            monthlyPrice: 9900,
            yearlyPrice: 99000,
            maxProjects: 10,
            maxEventsPerMonth: 1000000,
            maxTeamMembers: 20,
            retentionDays: 365,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'multiple_projects',
                '365_day_retention',
                'priority_support',
                'api_access',
                'csv_export',
                'integrations',
                'custom_reports',
                'mfa_support',
                'audit_logs',
                'gdpr_tools',
            ],
        },
        {
            tier: client_1.PlanTier.ENTERPRISE,
            name: 'Enterprise',
            description: 'For large organizations with custom requirements',
            monthlyPrice: 49900,
            yearlyPrice: 499000,
            maxProjects: -1,
            maxEventsPerMonth: -1,
            maxTeamMembers: -1,
            retentionDays: 730,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'unlimited_projects',
                '2_year_retention',
                'dedicated_support',
                'api_access',
                'csv_export',
                'integrations',
                'custom_reports',
                'mfa_support',
                'audit_logs',
                'gdpr_tools',
                'sso_saml',
                'custom_branding',
                'sla_guarantee',
                'dedicated_infrastructure',
                'onboarding',
            ],
        },
    ];
    for (const plan of plans) {
        await prisma.plan.upsert({
            where: { tier: plan.tier },
            update: {
                name: plan.name,
                description: plan.description,
                monthlyPrice: plan.monthlyPrice,
                yearlyPrice: plan.yearlyPrice,
                maxProjects: plan.maxProjects,
                maxEventsPerMonth: plan.maxEventsPerMonth,
                maxTeamMembers: plan.maxTeamMembers,
                retentionDays: plan.retentionDays,
                features: plan.features,
            },
            create: {
                tier: plan.tier,
                name: plan.name,
                description: plan.description,
                monthlyPrice: plan.monthlyPrice,
                yearlyPrice: plan.yearlyPrice,
                maxProjects: plan.maxProjects,
                maxEventsPerMonth: plan.maxEventsPerMonth,
                maxTeamMembers: plan.maxTeamMembers,
                retentionDays: plan.retentionDays,
                features: plan.features,
            },
        });
        console.log(`  ✓ Plan "${plan.name}" created/updated`);
    }
    console.log('Billing plans seeded successfully!\n');
}
async function main() {
    console.log('Seeding database...\n');
    await seedPlans();
    const passwordHash = await bcrypt.hash('demo123456', 12);
    const demoUser = await prisma.user.upsert({
        where: { email: 'demo@trackpro.io' },
        update: {},
        create: {
            name: 'Demo User',
            email: 'demo@trackpro.io',
            passwordHash,
        },
    });
    console.log('Created demo user:', demoUser.email);
    const demoTenant = await prisma.tenant.upsert({
        where: { slug: 'demo-company' },
        update: {},
        create: {
            name: 'Demo Company',
            slug: 'demo-company',
        },
    });
    console.log('Created demo tenant:', demoTenant.name);
    await prisma.membership.upsert({
        where: {
            userId_tenantId: {
                userId: demoUser.id,
                tenantId: demoTenant.id,
            },
        },
        update: {},
        create: {
            userId: demoUser.id,
            tenantId: demoTenant.id,
            role: client_1.MemberRole.OWNER,
        },
    });
    console.log('Created membership for demo user');
    const demoProject = await prisma.project.upsert({
        where: {
            tenantId_domain: {
                tenantId: demoTenant.id,
                domain: 'demo.trackpro.io',
            },
        },
        update: {},
        create: {
            tenantId: demoTenant.id,
            name: 'Demo Project',
            domain: 'demo.trackpro.io',
            timezone: 'America/Sao_Paulo',
            retentionDays: 90,
        },
    });
    console.log('Created demo project:', demoProject.name);
    console.log('Seed completed!');
    console.log('\nDemo credentials:');
    console.log('Email: demo@trackpro.io');
    console.log('Password: demo123456');
}
main()
    .catch((e) => {
    console.error(e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=seed.js.map