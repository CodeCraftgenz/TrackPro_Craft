export declare class PrivacyModule {
}
//# sourceMappingURL=privacy.module.d.ts.map