export declare class ReportsModule {
}
//# sourceMappingURL=reports.module.d.ts.map