import { OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PlanTier } from '@prisma/client';
interface PlanDefinition {
    tier: PlanTier;
    name: string;
    description: string;
    monthlyPrice: number;
    yearlyPrice: number;
    maxProjects: number;
    maxEventsPerMonth: number;
    maxTeamMembers: number;
    retentionDays: number;
    features: string[];
}
export declare class PlansService implements OnModuleInit {
    private readonly prisma;
    private readonly logger;
    static readonly PLANS: PlanDefinition[];
    constructor(prisma: PrismaService);
    onModuleInit(): Promise<void>;
    seedPlans(): Promise<void>;
    getPlans(): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        retentionDays: number;
        isActive: boolean;
        tier: import("@prisma/client").$Enums.PlanTier;
        monthlyPrice: number;
        yearlyPrice: number;
        stripePriceIdMonthly: string | null;
        stripePriceIdYearly: string | null;
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        features: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
    getPlanByTier(tier: PlanTier): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        retentionDays: number;
        isActive: boolean;
        tier: import("@prisma/client").$Enums.PlanTier;
        monthlyPrice: number;
        yearlyPrice: number;
        stripePriceIdMonthly: string | null;
        stripePriceIdYearly: string | null;
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        features: import("@prisma/client/runtime/library").JsonValue;
    } | null>;
    getPlanLimits(tier: PlanTier): Promise<{
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        retentionDays: number;
    }>;
    planHasFeature(tier: PlanTier, feature: string): Promise<boolean>;
    updateStripePriceIds(tier: PlanTier, monthlyPriceId: string, yearlyPriceId: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        retentionDays: number;
        isActive: boolean;
        tier: import("@prisma/client").$Enums.PlanTier;
        monthlyPrice: number;
        yearlyPrice: number;
        stripePriceIdMonthly: string | null;
        stripePriceIdYearly: string | null;
        maxProjects: number;
        maxEventsPerMonth: number;
        maxTeamMembers: number;
        features: import("@prisma/client/runtime/library").JsonValue;
    }>;
    getPlanComparison(): Promise<{
        plans: {
            id: string;
            name: string;
            tier: import("@prisma/client").$Enums.PlanTier;
            description: string | null;
            monthlyPrice: number;
            yearlyPrice: number;
            limits: {
                projects: string | number;
                eventsPerMonth: string;
                teamMembers: string | number;
                retentionDays: number;
            };
        }[];
        features: {
            availability: Record<import("@prisma/client").$Enums.PlanTier, boolean>;
            key: string;
            label: string;
        }[];
    }>;
}
export {};
//# sourceMappingURL=plans.service.d.ts.map