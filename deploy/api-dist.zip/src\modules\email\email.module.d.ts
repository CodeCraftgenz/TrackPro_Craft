export declare class EmailModule {
}
//# sourceMappingURL=email.module.d.ts.map