import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { EncryptionService } from '../integrations/encryption.service';
interface MfaSetupResult {
    secret: string;
    qrCodeUrl: string;
    backupCodes: string[];
}
interface MfaVerifyResult {
    success: boolean;
    backupCodeUsed?: boolean;
}
export declare class MfaService {
    private readonly configService;
    private readonly prisma;
    private readonly encryptionService;
    private readonly logger;
    private readonly issuer;
    constructor(configService: ConfigService, prisma: PrismaService, encryptionService: EncryptionService);
    setupMfa(userId: string): Promise<MfaSetupResult>;
    verifyAndEnableMfa(userId: string, token: string): Promise<boolean>;
    verifyMfaToken(userId: string, token: string): Promise<MfaVerifyResult>;
    disableMfa(userId: string, token: string): Promise<boolean>;
    regenerateBackupCodes(userId: string, token: string): Promise<string[]>;
    isMfaEnabled(userId: string): Promise<boolean>;
    getMfaStatus(userId: string): Promise<{
        enabled: boolean;
        backupCodesRemaining: number;
    }>;
    private generateBackupCodes;
}
export {};
//# sourceMappingURL=mfa.service.d.ts.map