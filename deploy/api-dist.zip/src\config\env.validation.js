"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnvironmentVariables = exports.Environment = void 0;
exports.validate = validate;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
var Environment;
(function (Environment) {
    Environment["Development"] = "development";
    Environment["Production"] = "production";
    Environment["Test"] = "test";
})(Environment || (exports.Environment = Environment = {}));
class EnvironmentVariables {
    NODE_ENV = Environment.Development;
    PORT = 3001;
    DATABASE_URL;
    JWT_SECRET;
    JWT_EXPIRES_IN = '15m';
    ENCRYPTION_KEY;
    CLICKHOUSE_HOST;
    CLICKHOUSE_DATABASE;
    CLICKHOUSE_USER;
    CLICKHOUSE_PASSWORD;
    REDIS_HOST;
    REDIS_PORT;
    GOOGLE_CLIENT_ID;
    GOOGLE_CLIENT_SECRET;
    MICROSOFT_CLIENT_ID;
    MICROSOFT_CLIENT_SECRET;
    CORS_ORIGIN;
    FRONTEND_URL;
}
exports.EnvironmentVariables = EnvironmentVariables;
__decorate([
    (0, class_validator_1.IsEnum)(Environment),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "NODE_ENV", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], EnvironmentVariables.prototype, "PORT", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'DATABASE_URL is required' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "DATABASE_URL", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'JWT_SECRET is required' }),
    (0, class_validator_1.MinLength)(32, { message: 'JWT_SECRET must be at least 32 characters' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "JWT_SECRET", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "JWT_EXPIRES_IN", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "ENCRYPTION_KEY", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'CLICKHOUSE_HOST is required' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "CLICKHOUSE_HOST", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'CLICKHOUSE_DATABASE is required' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "CLICKHOUSE_DATABASE", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "CLICKHOUSE_USER", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "CLICKHOUSE_PASSWORD", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "REDIS_HOST", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], EnvironmentVariables.prototype, "REDIS_PORT", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "GOOGLE_CLIENT_ID", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "GOOGLE_CLIENT_SECRET", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "MICROSOFT_CLIENT_ID", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "MICROSOFT_CLIENT_SECRET", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'CORS_ORIGIN is required' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "CORS_ORIGIN", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'FRONTEND_URL is required' }),
    __metadata("design:type", String)
], EnvironmentVariables.prototype, "FRONTEND_URL", void 0);
function validate(config) {
    const isProduction = config.NODE_ENV === 'production';
    const transformedConfig = {
        ...config,
        PORT: config.PORT ? parseInt(config.PORT, 10) : 3001,
        REDIS_PORT: config.REDIS_PORT
            ? parseInt(config.REDIS_PORT, 10)
            : undefined,
    };
    const validatedConfig = (0, class_transformer_1.plainToInstance)(EnvironmentVariables, transformedConfig, {
        enableImplicitConversion: true,
    });
    const errors = (0, class_validator_1.validateSync)(validatedConfig, {
        skipMissingProperties: false,
    });
    if (errors.length > 0) {
        const errorMessages = errors
            .map((error) => {
            const constraints = error.constraints
                ? Object.values(error.constraints)
                : ['Invalid value'];
            return `${error.property}: ${constraints.join(', ')}`;
        })
            .join('\n');
        throw new Error(`Environment validation failed:\n${errorMessages}`);
    }
    if (isProduction) {
        if (!validatedConfig.ENCRYPTION_KEY) {
            throw new Error('ENCRYPTION_KEY is required in production environment');
        }
        if (validatedConfig.ENCRYPTION_KEY.length < 32) {
            throw new Error('ENCRYPTION_KEY must be at least 32 characters in production');
        }
        if (validatedConfig.JWT_EXPIRES_IN === '7d') {
            console.warn('[Security Warning] JWT_EXPIRES_IN is set to 7 days. Consider using shorter expiration for access tokens.');
        }
    }
    return validatedConfig;
}
//# sourceMappingURL=env.validation.js.map