export declare class ProjectsModule {
}
//# sourceMappingURL=projects.module.d.ts.map