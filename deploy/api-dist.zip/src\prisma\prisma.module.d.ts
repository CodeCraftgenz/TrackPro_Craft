export declare class PrismaModule {
}
//# sourceMappingURL=prisma.module.d.ts.map