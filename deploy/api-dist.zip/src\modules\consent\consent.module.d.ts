export declare class ConsentModule {
}
//# sourceMappingURL=consent.module.d.ts.map