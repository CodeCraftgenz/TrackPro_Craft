export declare enum Environment {
    Development = "development",
    Production = "production",
    Test = "test"
}
export declare class EnvironmentVariables {
    NODE_ENV: Environment;
    PORT: number;
    DATABASE_URL: string;
    JWT_SECRET: string;
    JWT_EXPIRES_IN: string;
    ENCRYPTION_KEY?: string;
    CLICKHOUSE_HOST: string;
    CLICKHOUSE_DATABASE: string;
    CLICKHOUSE_USER?: string;
    CLICKHOUSE_PASSWORD?: string;
    REDIS_HOST?: string;
    REDIS_PORT?: number;
    GOOGLE_CLIENT_ID?: string;
    GOOGLE_CLIENT_SECRET?: string;
    MICROSOFT_CLIENT_ID?: string;
    MICROSOFT_CLIENT_SECRET?: string;
    CORS_ORIGIN: string;
    FRONTEND_URL: string;
}
export declare function validate(config: Record<string, unknown>): EnvironmentVariables;
//# sourceMappingURL=env.validation.d.ts.map