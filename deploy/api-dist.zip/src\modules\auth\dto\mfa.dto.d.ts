export declare class VerifyMfaDto {
    token: string;
}
export declare class DisableMfaDto {
    token: string;
}
export declare class RegenerateBackupCodesDto {
    token: string;
}
export declare class MfaSetupResponseDto {
    secret: string;
    qrCodeUrl: string;
    backupCodes: string[];
}
export declare class MfaStatusResponseDto {
    enabled: boolean;
    backupCodesRemaining?: number;
}
export declare class LoginWithMfaDto {
    email: string;
    password: string;
    mfaToken?: string;
}
//# sourceMappingURL=mfa.dto.d.ts.map