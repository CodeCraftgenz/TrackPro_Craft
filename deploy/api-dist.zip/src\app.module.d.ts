export declare class AppModule {
}
//# sourceMappingURL=app.module.d.ts.map