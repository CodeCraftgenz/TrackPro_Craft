import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
export declare enum AuditAction {
    USER_LOGIN = "user.login",
    USER_LOGIN_FAILED = "user.login_failed",
    USER_LOGOUT = "user.logout",
    USER_REGISTER = "user.register",
    PASSWORD_CHANGE = "user.password_change",
    PASSWORD_RESET_REQUEST = "user.password_reset_request",
    PASSWORD_RESET_COMPLETE = "user.password_reset_complete",
    MFA_ENABLED = "user.mfa_enabled",
    MFA_DISABLED = "user.mfa_disabled",
    MFA_BACKUP_USED = "user.mfa_backup_used",
    MFA_BACKUP_REGENERATED = "user.mfa_backup_regenerated",
    USER_CREATED = "user.created",
    USER_UPDATED = "user.updated",
    USER_DELETED = "user.deleted",
    USER_ROLE_CHANGED = "user.role_changed",
    TENANT_CREATED = "tenant.created",
    TENANT_UPDATED = "tenant.updated",
    TENANT_DELETED = "tenant.deleted",
    MEMBER_INVITED = "tenant.member_invited",
    MEMBER_REMOVED = "tenant.member_removed",
    PROJECT_CREATED = "project.created",
    PROJECT_UPDATED = "project.updated",
    PROJECT_DELETED = "project.deleted",
    PROJECT_ARCHIVED = "project.archived",
    API_KEY_CREATED = "api_key.created",
    API_KEY_REVOKED = "api_key.revoked",
    API_KEY_USED = "api_key.used",
    INTEGRATION_CONNECTED = "integration.connected",
    INTEGRATION_DISCONNECTED = "integration.disconnected",
    INTEGRATION_UPDATED = "integration.updated",
    INTEGRATION_ERROR = "integration.error",
    DATA_EXPORTED = "data.exported",
    DATA_DELETED = "data.deleted",
    DATA_ACCESS = "data.access",
    CONSENT_UPDATED = "privacy.consent_updated",
    DATA_SUBJECT_REQUEST = "privacy.data_subject_request",
    DATA_DELETION_REQUEST = "privacy.deletion_request",
    ADMIN_ACTION = "admin.action",
    SETTINGS_CHANGED = "admin.settings_changed",
    BACKUP_CREATED = "admin.backup_created"
}
export declare enum AuditResource {
    USER = "user",
    TENANT = "tenant",
    PROJECT = "project",
    API_KEY = "api_key",
    INTEGRATION = "integration",
    EXPORT = "export",
    CONSENT = "consent",
    LEAD = "lead",
    SETTINGS = "settings"
}
export declare enum AuditSeverity {
    INFO = "info",
    WARNING = "warning",
    CRITICAL = "critical"
}
export interface AuditLogData {
    tenantId: string;
    actorUserId?: string;
    action: AuditAction | string;
    resource: AuditResource | string;
    resourceId?: string;
    payload?: Record<string, unknown>;
    ipAddress?: string;
    userAgent?: string;
    severity?: AuditSeverity;
    metadata?: {
        sessionId?: string;
        requestId?: string;
        country?: string;
        city?: string;
    };
}
export interface AuditLogFilters {
    limit?: number;
    offset?: number;
    action?: string;
    resource?: string;
    actorUserId?: string;
    severity?: AuditSeverity;
    startDate?: Date;
    endDate?: Date;
    searchTerm?: string;
}
export declare class AuditService {
    private readonly prisma;
    private readonly configService;
    private readonly logger;
    private readonly retentionDays;
    constructor(prisma: PrismaService, configService: ConfigService);
    log(data: AuditLogData): Promise<void>;
    getLogs(tenantId: string, filters?: AuditLogFilters): Promise<{
        logs: ({
            actor: {
                name: string;
                id: string;
                email: string;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            tenantId: string;
            action: string;
            resource: string;
            resourceId: string | null;
            payload: import("@prisma/client/runtime/library").JsonValue | null;
            ipAddress: string | null;
            userAgent: string | null;
            actorUserId: string | null;
        })[];
        total: number;
        limit: number;
        offset: number;
    }>;
    getLogsForResource(tenantId: string, resource: AuditResource | string, resourceId: string, limit?: number): Promise<({
        actor: {
            name: string;
            id: string;
            email: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        tenantId: string;
        action: string;
        resource: string;
        resourceId: string | null;
        payload: import("@prisma/client/runtime/library").JsonValue | null;
        ipAddress: string | null;
        userAgent: string | null;
        actorUserId: string | null;
    })[]>;
    getLogsForUser(tenantId: string, userId: string, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        tenantId: string;
        action: string;
        resource: string;
        resourceId: string | null;
        payload: import("@prisma/client/runtime/library").JsonValue | null;
        ipAddress: string | null;
        userAgent: string | null;
        actorUserId: string | null;
    }[]>;
    getSecurityLogs(tenantId: string, days?: number): Promise<({
        actor: {
            name: string;
            id: string;
            email: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        tenantId: string;
        action: string;
        resource: string;
        resourceId: string | null;
        payload: import("@prisma/client/runtime/library").JsonValue | null;
        ipAddress: string | null;
        userAgent: string | null;
        actorUserId: string | null;
    })[]>;
    getAuditStats(tenantId: string, days?: number): Promise<{
        totalLogs: number;
        actionBreakdown: {
            action: string;
            count: number;
        }[];
        dailyActivity: unknown;
    }>;
    exportLogs(tenantId: string, startDate: Date, endDate: Date): Promise<string>;
    cleanupOldLogs(): Promise<number>;
    private sanitizePayload;
    private getSeverityForAction;
}
//# sourceMappingURL=audit.service.d.ts.map