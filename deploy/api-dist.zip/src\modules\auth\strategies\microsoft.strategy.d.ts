import { Strategy } from 'passport-microsoft';
import { ConfigService } from '@nestjs/config';
interface MicrosoftProfile {
    id: string;
    displayName: string;
    emails?: Array<{
        value: string;
    }>;
    _json?: {
        mail?: string;
        userPrincipalName?: string;
    };
}
declare const MicrosoftStrategy_base: new (...args: any[]) => Strategy;
export declare class MicrosoftStrategy extends MicrosoftStrategy_base {
    constructor(configService: ConfigService);
    validate(accessToken: string, _refreshToken: string, profile: MicrosoftProfile, done: (err: Error | null, user?: unknown) => void): Promise<void>;
}
export {};
//# sourceMappingURL=microsoft.strategy.d.ts.map