"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const passport_1 = require("@nestjs/passport");
const config_1 = require("@nestjs/config");
const auth_service_1 = require("./auth.service");
const auth_dto_1 = require("./dto/auth.dto");
const current_user_decorator_1 = require("./decorators/current-user.decorator");
let AuthController = class AuthController {
    authService;
    configService;
    constructor(authService, configService) {
        this.authService = authService;
        this.configService = configService;
    }
    getFrontendUrl() {
        return this.configService.get('FRONTEND_URL', 'http://localhost:3000');
    }
    isProduction() {
        return this.configService.get('NODE_ENV') === 'production';
    }
    setAuthCookies(res, tokens) {
        const isSecure = this.isProduction();
        const sameSite = isSecure ? 'none' : 'lax';
        res.cookie('accessToken', tokens.accessToken, {
            httpOnly: true,
            secure: isSecure,
            sameSite,
            maxAge: 15 * 60 * 1000,
            path: '/',
        });
        res.cookie('refreshToken', tokens.refreshToken, {
            httpOnly: true,
            secure: isSecure,
            sameSite,
            maxAge: 7 * 24 * 60 * 60 * 1000,
            path: '/api/auth',
        });
    }
    clearAuthCookies(res) {
        const isSecure = this.isProduction();
        const sameSite = isSecure ? 'none' : 'lax';
        res.clearCookie('accessToken', {
            httpOnly: true,
            secure: isSecure,
            sameSite,
            path: '/',
        });
        res.clearCookie('refreshToken', {
            httpOnly: true,
            secure: isSecure,
            sameSite,
            path: '/api/auth',
        });
    }
    async register(dto, res) {
        const result = await this.authService.register(dto);
        this.setAuthCookies(res, {
            accessToken: result.accessToken,
            refreshToken: result.refreshToken,
        });
        return {
            user: result.user,
            expiresIn: result.expiresIn,
        };
    }
    async login(dto, res) {
        const result = await this.authService.login(dto);
        this.setAuthCookies(res, {
            accessToken: result.accessToken,
            refreshToken: result.refreshToken,
        });
        return {
            user: result.user,
            expiresIn: result.expiresIn,
        };
    }
    async refresh(req, res, dto) {
        const refreshToken = dto.refreshToken || req.cookies?.refreshToken;
        if (!refreshToken) {
            throw new Error('Refresh token not provided');
        }
        const result = await this.authService.refreshToken({ refreshToken });
        this.setAuthCookies(res, {
            accessToken: result.accessToken,
            refreshToken: result.refreshToken,
        });
        return {
            expiresIn: result.expiresIn,
        };
    }
    async logout(user, req, res, dto) {
        const refreshToken = dto.refreshToken || req.cookies?.refreshToken;
        if (refreshToken) {
            await this.authService.logout(user.sub, refreshToken);
        }
        this.clearAuthCookies(res);
    }
    async googleAuth() {
    }
    async googleAuthCallback(req, res) {
        const oauthUser = req.user;
        const tokens = await this.authService.validateOAuthLogin(oauthUser);
        this.setAuthCookies(res, tokens);
        const frontendUrl = this.getFrontendUrl();
        res.redirect(`${frontendUrl}/auth/callback?success=true`);
    }
    async microsoftAuth() {
    }
    async microsoftAuthCallback(req, res) {
        const oauthUser = req.user;
        const tokens = await this.authService.validateOAuthLogin(oauthUser);
        this.setAuthCookies(res, tokens);
        const frontendUrl = this.getFrontendUrl();
        res.redirect(`${frontendUrl}/auth/callback?success=true`);
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('register'),
    (0, swagger_1.ApiOperation)({ summary: 'Register a new user' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'User registered successfully' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Bad request' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.RegisterDto, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "register", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Login with email and password' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Login successful' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid credentials' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.LoginDto, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Refresh access token' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Token refreshed successfully' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid refresh token' }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, auth_dto_1.RefreshTokenDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('logout'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Logout user' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Logout successful' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object, auth_dto_1.LogoutDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logout", null);
__decorate([
    (0, common_1.Get)('google'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google')),
    (0, swagger_1.ApiOperation)({ summary: 'Initiate Google OAuth login' }),
    (0, swagger_1.ApiResponse)({ status: 302, description: 'Redirects to Google' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuth", null);
__decorate([
    (0, common_1.Get)('google/callback'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google')),
    (0, swagger_1.ApiOperation)({ summary: 'Google OAuth callback' }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuthCallback", null);
__decorate([
    (0, common_1.Get)('microsoft'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('microsoft')),
    (0, swagger_1.ApiOperation)({ summary: 'Initiate Microsoft OAuth login' }),
    (0, swagger_1.ApiResponse)({ status: 302, description: 'Redirects to Microsoft' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "microsoftAuth", null);
__decorate([
    (0, common_1.Get)('microsoft/callback'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('microsoft')),
    (0, swagger_1.ApiOperation)({ summary: 'Microsoft OAuth callback' }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "microsoftAuthCallback", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('auth'),
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        config_1.ConfigService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map