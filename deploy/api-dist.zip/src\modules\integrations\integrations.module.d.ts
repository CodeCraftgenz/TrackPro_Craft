export declare class IntegrationsModule {
}
//# sourceMappingURL=integrations.module.d.ts.map