export {};
//# sourceMappingURL=seed.d.ts.map