export declare class BillingModule {
}
//# sourceMappingURL=billing.module.d.ts.map