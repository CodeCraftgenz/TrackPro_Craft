import * as Sentry from '@sentry/nestjs';
export declare function initSentry(): void;
export { Sentry };
//# sourceMappingURL=sentry.d.ts.map