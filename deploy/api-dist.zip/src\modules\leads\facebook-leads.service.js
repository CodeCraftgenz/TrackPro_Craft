"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FacebookLeadsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookLeadsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../prisma/prisma.service");
const encryption_service_1 = require("../integrations/encryption.service");
const leads_service_1 = require("./leads.service");
let FacebookLeadsService = FacebookLeadsService_1 = class FacebookLeadsService {
    prisma;
    encryption;
    configService;
    leadsService;
    logger = new common_1.Logger(FacebookLeadsService_1.name);
    graphApiUrl = 'https://graph.facebook.com/v18.0';
    constructor(prisma, encryption, configService, leadsService) {
        this.prisma = prisma;
        this.encryption = encryption;
        this.configService = configService;
        this.leadsService = leadsService;
    }
    getOAuthUrl(projectId, tenantId) {
        const clientId = this.configService.get('FACEBOOK_APP_ID');
        const redirectUri = this.configService.get('FACEBOOK_LEADS_CALLBACK_URL', 'http://localhost:3001/api/v1/leads/oauth/facebook/callback');
        const state = Buffer.from(JSON.stringify({ projectId, tenantId })).toString('base64');
        const scopes = [
            'pages_show_list',
            'pages_read_engagement',
            'leads_retrieval',
            'pages_manage_ads',
        ].join(',');
        return `https://www.facebook.com/v18.0/dialog/oauth?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scopes}&state=${state}&response_type=code`;
    }
    async exchangeCodeForToken(code) {
        const clientId = this.configService.get('FACEBOOK_APP_ID');
        const clientSecret = this.configService.get('FACEBOOK_APP_SECRET');
        const redirectUri = this.configService.get('FACEBOOK_LEADS_CALLBACK_URL', 'http://localhost:3001/api/v1/leads/oauth/facebook/callback');
        const response = await fetch(`${this.graphApiUrl}/oauth/access_token?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&client_secret=${clientSecret}&code=${code}`);
        if (!response.ok) {
            const error = (await response.json());
            throw new Error(error.error?.message || 'Failed to exchange code for token');
        }
        const data = (await response.json());
        const longLivedResponse = await fetch(`${this.graphApiUrl}/oauth/access_token?grant_type=fb_exchange_token&client_id=${clientId}&client_secret=${clientSecret}&fb_exchange_token=${data.access_token}`);
        if (longLivedResponse.ok) {
            const longLivedData = (await longLivedResponse.json());
            return {
                accessToken: longLivedData.access_token,
                expiresIn: longLivedData.expires_in || 5184000,
            };
        }
        return {
            accessToken: data.access_token,
            expiresIn: data.expires_in || 3600,
        };
    }
    async getPages(accessToken) {
        const response = await fetch(`${this.graphApiUrl}/me/accounts?fields=id,name,access_token&access_token=${accessToken}`);
        if (!response.ok) {
            const error = (await response.json());
            throw new Error(error.error?.message || 'Failed to fetch pages');
        }
        const data = (await response.json());
        return data.data;
    }
    async getLeadForms(pageId, pageAccessToken) {
        const response = await fetch(`${this.graphApiUrl}/${pageId}/leadgen_forms?fields=id,name,status,locale&access_token=${pageAccessToken}`);
        if (!response.ok) {
            const error = (await response.json());
            throw new Error(error.error?.message || 'Failed to fetch lead forms');
        }
        const data = (await response.json());
        return data.data;
    }
    async getLeadsFromForm(formId, pageAccessToken, since) {
        let url = `${this.graphApiUrl}/${formId}/leads?fields=id,created_time,field_data&access_token=${pageAccessToken}`;
        if (since) {
            url += `&filtering=[{"field":"time_created","operator":"GREATER_THAN","value":${since}}]`;
        }
        const allLeads = [];
        let nextUrl = url;
        while (nextUrl) {
            const response = await fetch(nextUrl);
            if (!response.ok) {
                const error = (await response.json());
                throw new Error(error.error?.message || 'Failed to fetch leads');
            }
            const data = (await response.json());
            allLeads.push(...data.data);
            nextUrl = data.paging?.next || null;
        }
        return allLeads;
    }
    async subscribeToLeadgenWebhook(pageId, pageAccessToken) {
        const response = await fetch(`${this.graphApiUrl}/${pageId}/subscribed_apps?subscribed_fields=leadgen&access_token=${pageAccessToken}`, { method: 'POST' });
        if (!response.ok) {
            const error = (await response.json());
            this.logger.error(`Failed to subscribe to leadgen webhook: ${error.error?.message}`);
            return false;
        }
        return true;
    }
    async processWebhook(entry) {
        for (const pageEntry of entry) {
            const pageId = pageEntry.id;
            for (const change of pageEntry.changes) {
                if (change.field !== 'leadgen')
                    continue;
                const { form_id, leadgen_id } = change.value;
                const integration = await this.prisma.leadIntegration.findFirst({
                    where: {
                        platform: client_1.LeadPlatform.FACEBOOK,
                        pageId,
                        status: client_1.LeadIntegrationStatus.ACTIVE,
                    },
                });
                if (!integration || !integration.accessTokenEncrypted) {
                    this.logger.warn(`No active integration found for page ${pageId}`);
                    continue;
                }
                const accessToken = this.encryption.decrypt(integration.accessTokenEncrypted);
                try {
                    const leadResponse = await fetch(`${this.graphApiUrl}/${leadgen_id}?fields=id,created_time,field_data&access_token=${accessToken}`);
                    if (!leadResponse.ok) {
                        this.logger.error(`Failed to fetch lead ${leadgen_id}`);
                        continue;
                    }
                    const lead = (await leadResponse.json());
                    const leadData = {};
                    for (const field of lead.field_data) {
                        leadData[field.name] = field.values[0] || '';
                    }
                    await this.leadsService.processExternalLead(integration.projectId, client_1.LeadPlatform.FACEBOOK, {
                        externalId: lead.id,
                        formId: form_id,
                        formName: `Facebook Form ${form_id}`,
                        email: leadData.email,
                        name: leadData.full_name || `${leadData.first_name || ''} ${leadData.last_name || ''}`.trim(),
                        phone: leadData.phone_number,
                        customFields: leadData,
                    });
                    this.logger.log(`Processed Facebook lead: ${lead.id}`);
                }
                catch (error) {
                    this.logger.error(`Error processing Facebook lead: ${error}`);
                }
            }
        }
    }
    async syncLeads(projectId) {
        const integration = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
        });
        if (!integration || !integration.accessTokenEncrypted) {
            throw new Error('Facebook integration not configured');
        }
        const accessToken = this.encryption.decrypt(integration.accessTokenEncrypted);
        const formIds = integration.formIds || [];
        let synced = 0;
        let errors = 0;
        const since = integration.lastSyncAt
            ? Math.floor(integration.lastSyncAt.getTime() / 1000)
            : undefined;
        for (const formId of formIds) {
            try {
                const leads = await this.getLeadsFromForm(formId, accessToken, since);
                for (const lead of leads) {
                    try {
                        const leadData = {};
                        for (const field of lead.field_data) {
                            leadData[field.name] = field.values[0] || '';
                        }
                        await this.leadsService.processExternalLead(projectId, client_1.LeadPlatform.FACEBOOK, {
                            externalId: lead.id,
                            formId,
                            formName: `Facebook Form ${formId}`,
                            email: leadData.email,
                            name: leadData.full_name ||
                                `${leadData.first_name || ''} ${leadData.last_name || ''}`.trim(),
                            phone: leadData.phone_number,
                            customFields: leadData,
                        });
                        synced++;
                    }
                    catch {
                        errors++;
                    }
                }
            }
            catch (error) {
                this.logger.error(`Error syncing leads from form ${formId}: ${error}`);
                errors++;
            }
        }
        await this.prisma.leadIntegration.update({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
            data: { lastSyncAt: new Date() },
        });
        return { synced, errors };
    }
};
exports.FacebookLeadsService = FacebookLeadsService;
exports.FacebookLeadsService = FacebookLeadsService = FacebookLeadsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        encryption_service_1.EncryptionService,
        config_1.ConfigService,
        leads_service_1.LeadsService])
], FacebookLeadsService);
//# sourceMappingURL=facebook-leads.service.js.map