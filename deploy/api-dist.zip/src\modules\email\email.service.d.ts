import { ConfigService } from '@nestjs/config';
export interface EmailOptions {
    to: string | string[];
    subject: string;
    html?: string;
    text?: string;
    from?: string;
    replyTo?: string;
    templateId?: string;
    templateData?: Record<string, unknown>;
    attachments?: Array<{
        filename: string;
        content: Buffer | string;
        contentType?: string;
    }>;
}
export interface EmailResult {
    success: boolean;
    messageId?: string;
    error?: string;
}
export declare class EmailService {
    private readonly configService;
    private readonly logger;
    private readonly provider;
    private readonly defaultFrom;
    private smtpTransporter?;
    constructor(configService: ConfigService);
    private initializeProvider;
    send(options: EmailOptions): Promise<EmailResult>;
    private sendViaSendGrid;
    private sendViaSMTP;
    private sendViaConsole;
    sendWelcomeEmail(to: string, name: string): Promise<EmailResult>;
    sendPasswordResetEmail(to: string, name: string, resetToken: string): Promise<EmailResult>;
    sendLeadNotificationEmail(to: string, leadData: {
        name?: string;
        email?: string;
        phone?: string;
        formName: string;
        projectName: string;
    }): Promise<EmailResult>;
    sendExportReadyEmail(to: string, exportData: {
        type: string;
        downloadUrl: string;
        expiresAt: Date;
    }): Promise<EmailResult>;
}
//# sourceMappingURL=email.service.d.ts.map