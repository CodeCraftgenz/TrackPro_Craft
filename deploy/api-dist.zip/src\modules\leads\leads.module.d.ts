export declare class LeadsModule {
}
//# sourceMappingURL=leads.module.d.ts.map