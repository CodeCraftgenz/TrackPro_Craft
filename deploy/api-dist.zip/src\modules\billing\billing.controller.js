"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const roles_guard_1 = require("../auth/guards/roles.guard");
const roles_decorator_1 = require("../auth/decorators/roles.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const billing_service_1 = require("./billing.service");
const plans_service_1 = require("./plans.service");
const billing_dto_1 = require("./billing.dto");
let BillingController = class BillingController {
    billingService;
    plansService;
    constructor(billingService, plansService) {
        this.billingService = billingService;
        this.plansService = plansService;
    }
    async getPlans() {
        return this.plansService.getPlans();
    }
    async getPlanComparison() {
        return this.plansService.getPlanComparison();
    }
    async handleStripeWebhook(req, signature) {
        const payload = req.rawBody;
        if (!payload) {
            return { received: false, error: 'Missing raw body' };
        }
        await this.billingService.handleWebhook(payload, signature);
        return { received: true };
    }
    async getSubscription(user) {
        return this.billingService.getSubscription(user.tenantId);
    }
    async getUsageSummary(user) {
        return this.billingService.getUsageSummary(user.tenantId);
    }
    async getInvoices(user, limit) {
        return this.billingService.getInvoices(user.tenantId, limit || 10);
    }
    async createCheckoutSession(user, dto) {
        return this.billingService.createCheckoutSession({
            tenantId: user.tenantId,
            ...dto,
        });
    }
    async createPortalSession(user, dto) {
        return this.billingService.createCustomerPortalSession({
            tenantId: user.tenantId,
            returnUrl: dto.returnUrl,
        });
    }
    async cancelSubscription(user) {
        await this.billingService.cancelSubscription(user.tenantId, user.userId);
    }
    async resumeSubscription(user) {
        await this.billingService.resumeSubscription(user.tenantId, user.userId);
    }
    async checkPlanLimit(user, limitType) {
        return this.billingService.checkPlanLimit(user.tenantId, limitType);
    }
    async updateStripePriceIds(dto) {
        return this.plansService.updateStripePriceIds(dto.tier, dto.monthlyPriceId, dto.yearlyPriceId);
    }
};
exports.BillingController = BillingController;
__decorate([
    (0, common_1.Get)('plans'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all available plans' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: [billing_dto_1.PlanResponseDto] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getPlans", null);
__decorate([
    (0, common_1.Get)('plans/compare'),
    (0, swagger_1.ApiOperation)({ summary: 'Get plan comparison for pricing page' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: billing_dto_1.PlanComparisonResponseDto }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getPlanComparison", null);
__decorate([
    (0, common_1.Post)('webhooks/stripe'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Handle Stripe webhook events' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Webhook processed successfully' }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Headers)('stripe-signature')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "handleStripeWebhook", null);
__decorate([
    (0, common_1.Get)('subscription'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get current subscription' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: billing_dto_1.SubscriptionResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getSubscription", null);
__decorate([
    (0, common_1.Get)('usage'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get current usage summary' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: billing_dto_1.UsageSummaryResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getUsageSummary", null);
__decorate([
    (0, common_1.Get)('invoices'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get invoice history' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: [billing_dto_1.InvoiceResponseDto] }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getInvoices", null);
__decorate([
    (0, common_1.Post)('checkout'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('OWNER', 'ADMIN'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create checkout session for subscription' }),
    (0, swagger_1.ApiResponse)({ status: 201, type: billing_dto_1.CheckoutSessionResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, billing_dto_1.CreateCheckoutSessionDto]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "createCheckoutSession", null);
__decorate([
    (0, common_1.Post)('portal'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('OWNER', 'ADMIN'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create customer portal session' }),
    (0, swagger_1.ApiResponse)({ status: 201, type: billing_dto_1.CheckoutSessionResponseDto }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, billing_dto_1.CreatePortalSessionDto]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "createPortalSession", null);
__decorate([
    (0, common_1.Delete)('subscription'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('OWNER'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Cancel subscription at period end' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Subscription canceled' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "cancelSubscription", null);
__decorate([
    (0, common_1.Post)('subscription/resume'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('OWNER'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Resume canceled subscription' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Subscription resumed' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "resumeSubscription", null);
__decorate([
    (0, common_1.Get)('limits/check'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Check if action is allowed by plan limits' }),
    (0, swagger_1.ApiResponse)({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "checkPlanLimit", null);
__decorate([
    (0, common_1.Post)('admin/plans/stripe-prices'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)('OWNER'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Update Stripe price IDs for a plan (admin only)' }),
    (0, swagger_1.ApiResponse)({ status: 200, type: billing_dto_1.PlanResponseDto }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_dto_1.UpdateStripePriceIdsDto]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "updateStripePriceIds", null);
exports.BillingController = BillingController = __decorate([
    (0, swagger_1.ApiTags)('billing'),
    (0, common_1.Controller)('billing'),
    __metadata("design:paramtypes", [billing_service_1.BillingService,
        plans_service_1.PlansService])
], BillingController);
//# sourceMappingURL=billing.controller.js.map