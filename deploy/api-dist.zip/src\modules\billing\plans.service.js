"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PlansService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlansService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const client_1 = require("@prisma/client");
let PlansService = class PlansService {
    static { PlansService_1 = this; }
    prisma;
    logger = new common_1.Logger(PlansService_1.name);
    static PLANS = [
        {
            tier: client_1.PlanTier.FREE,
            name: 'Free',
            description: 'Get started with basic analytics',
            monthlyPrice: 0,
            yearlyPrice: 0,
            maxProjects: 1,
            maxEventsPerMonth: 10000,
            maxTeamMembers: 1,
            retentionDays: 30,
            features: [
                'basic_analytics',
                'single_project',
                '30_day_retention',
                'community_support',
            ],
        },
        {
            tier: client_1.PlanTier.STARTER,
            name: 'Starter',
            description: 'For small teams getting serious about analytics',
            monthlyPrice: 2900,
            yearlyPrice: 29000,
            maxProjects: 3,
            maxEventsPerMonth: 100000,
            maxTeamMembers: 5,
            retentionDays: 90,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'multiple_projects',
                '90_day_retention',
                'email_support',
                'api_access',
                'csv_export',
            ],
        },
        {
            tier: client_1.PlanTier.PROFESSIONAL,
            name: 'Professional',
            description: 'For growing businesses with advanced needs',
            monthlyPrice: 9900,
            yearlyPrice: 99000,
            maxProjects: 10,
            maxEventsPerMonth: 1000000,
            maxTeamMembers: 20,
            retentionDays: 365,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'multiple_projects',
                '365_day_retention',
                'priority_support',
                'api_access',
                'csv_export',
                'integrations',
                'custom_reports',
                'mfa_support',
                'audit_logs',
                'gdpr_tools',
            ],
        },
        {
            tier: client_1.PlanTier.ENTERPRISE,
            name: 'Enterprise',
            description: 'For large organizations with custom requirements',
            monthlyPrice: 49900,
            yearlyPrice: 499000,
            maxProjects: -1,
            maxEventsPerMonth: -1,
            maxTeamMembers: -1,
            retentionDays: 730,
            features: [
                'basic_analytics',
                'advanced_funnels',
                'unlimited_projects',
                '2_year_retention',
                'dedicated_support',
                'api_access',
                'csv_export',
                'integrations',
                'custom_reports',
                'mfa_support',
                'audit_logs',
                'gdpr_tools',
                'sso_saml',
                'custom_branding',
                'sla_guarantee',
                'dedicated_infrastructure',
                'onboarding',
            ],
        },
    ];
    constructor(prisma) {
        this.prisma = prisma;
    }
    async onModuleInit() {
        await this.seedPlans();
    }
    async seedPlans() {
        for (const planDef of PlansService_1.PLANS) {
            const existing = await this.prisma.plan.findUnique({
                where: { tier: planDef.tier },
            });
            if (!existing) {
                await this.prisma.plan.create({
                    data: {
                        tier: planDef.tier,
                        name: planDef.name,
                        description: planDef.description,
                        monthlyPrice: planDef.monthlyPrice,
                        yearlyPrice: planDef.yearlyPrice,
                        maxProjects: planDef.maxProjects,
                        maxEventsPerMonth: planDef.maxEventsPerMonth,
                        maxTeamMembers: planDef.maxTeamMembers,
                        retentionDays: planDef.retentionDays,
                        features: planDef.features,
                    },
                });
                this.logger.log(`Created plan: ${planDef.name}`);
            }
        }
    }
    async getPlans() {
        return this.prisma.plan.findMany({
            where: { isActive: true },
            orderBy: { monthlyPrice: 'asc' },
        });
    }
    async getPlanByTier(tier) {
        return this.prisma.plan.findUnique({
            where: { tier },
        });
    }
    async getPlanLimits(tier) {
        const plan = await this.getPlanByTier(tier);
        if (!plan) {
            return {
                maxProjects: 1,
                maxEventsPerMonth: 10000,
                maxTeamMembers: 1,
                retentionDays: 30,
            };
        }
        return {
            maxProjects: plan.maxProjects,
            maxEventsPerMonth: plan.maxEventsPerMonth,
            maxTeamMembers: plan.maxTeamMembers,
            retentionDays: plan.retentionDays,
        };
    }
    async planHasFeature(tier, feature) {
        const plan = await this.getPlanByTier(tier);
        if (!plan) {
            return false;
        }
        const features = plan.features;
        return features.includes(feature);
    }
    async updateStripePriceIds(tier, monthlyPriceId, yearlyPriceId) {
        return this.prisma.plan.update({
            where: { tier },
            data: {
                stripePriceIdMonthly: monthlyPriceId,
                stripePriceIdYearly: yearlyPriceId,
            },
        });
    }
    async getPlanComparison() {
        const plans = await this.getPlans();
        const allFeatures = [
            { key: 'basic_analytics', label: 'Basic Analytics' },
            { key: 'advanced_funnels', label: 'Advanced Funnels' },
            { key: 'multiple_projects', label: 'Multiple Projects' },
            { key: 'api_access', label: 'API Access' },
            { key: 'csv_export', label: 'CSV Export' },
            { key: 'integrations', label: 'Third-party Integrations' },
            { key: 'custom_reports', label: 'Custom Reports' },
            { key: 'mfa_support', label: 'Two-Factor Authentication' },
            { key: 'audit_logs', label: 'Audit Logs' },
            { key: 'gdpr_tools', label: 'GDPR Compliance Tools' },
            { key: 'sso_saml', label: 'SSO / SAML' },
            { key: 'custom_branding', label: 'Custom Branding' },
            { key: 'sla_guarantee', label: 'SLA Guarantee' },
            { key: 'dedicated_infrastructure', label: 'Dedicated Infrastructure' },
            { key: 'onboarding', label: 'Custom Onboarding' },
        ];
        return {
            plans: plans.map((plan) => ({
                id: plan.id,
                name: plan.name,
                tier: plan.tier,
                description: plan.description,
                monthlyPrice: plan.monthlyPrice,
                yearlyPrice: plan.yearlyPrice,
                limits: {
                    projects: plan.maxProjects === -1 ? 'Unlimited' : plan.maxProjects,
                    eventsPerMonth: plan.maxEventsPerMonth === -1 ? 'Unlimited' : plan.maxEventsPerMonth.toLocaleString(),
                    teamMembers: plan.maxTeamMembers === -1 ? 'Unlimited' : plan.maxTeamMembers,
                    retentionDays: plan.retentionDays,
                },
            })),
            features: allFeatures.map((feature) => ({
                ...feature,
                availability: plans.reduce((acc, plan) => {
                    const planFeatures = plan.features;
                    acc[plan.tier] = planFeatures.includes(feature.key);
                    return acc;
                }, {}),
            })),
        };
    }
};
exports.PlansService = PlansService;
exports.PlansService = PlansService = PlansService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PlansService);
//# sourceMappingURL=plans.service.js.map