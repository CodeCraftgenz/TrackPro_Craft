export declare class InternalModule {
}
//# sourceMappingURL=internal.module.d.ts.map