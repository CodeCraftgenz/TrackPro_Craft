export declare class AuditModule {
}
//# sourceMappingURL=audit.module.d.ts.map