import { ConfigService } from '@nestjs/config';
import { Request, Response } from 'express';
import { AuthService } from './auth.service';
import { LoginDto, RegisterDto, RefreshTokenDto, LogoutDto } from './dto/auth.dto';
import { JwtPayload } from './decorators/current-user.decorator';
export declare class AuthController {
    private readonly authService;
    private readonly configService;
    constructor(authService: AuthService, configService: ConfigService);
    private getFrontendUrl;
    private isProduction;
    private setAuthCookies;
    private clearAuthCookies;
    register(dto: RegisterDto, res: Response): Promise<{
        user: {
            id: string;
            email: string;
            name: string | null;
        } | undefined;
        expiresIn: number;
    }>;
    login(dto: LoginDto, res: Response): Promise<{
        user: {
            id: string;
            email: string;
            name: string | null;
        } | undefined;
        expiresIn: number;
    }>;
    refresh(req: Request, res: Response, dto: RefreshTokenDto): Promise<{
        expiresIn: number;
    }>;
    logout(user: JwtPayload, req: Request, res: Response, dto: LogoutDto): Promise<void>;
    googleAuth(): Promise<void>;
    googleAuthCallback(req: Request, res: Response): Promise<void>;
    microsoftAuth(): Promise<void>;
    microsoftAuthCallback(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=auth.controller.d.ts.map