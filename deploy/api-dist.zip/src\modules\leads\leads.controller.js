"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var LeadsOAuthController_1, PublicLeadsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicLeadsController = exports.LeadsOAuthController = exports.LeadsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const passport_1 = require("@nestjs/passport");
const client_1 = require("@prisma/client");
const config_1 = require("@nestjs/config");
const leads_service_1 = require("./leads.service");
const facebook_leads_service_1 = require("./facebook-leads.service");
const encryption_service_1 = require("../integrations/encryption.service");
const prisma_service_1 = require("../../prisma/prisma.service");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const leads_dto_1 = require("./dto/leads.dto");
const api_keys_service_1 = require("../projects/api-keys.service");
let LeadsController = class LeadsController {
    leadsService;
    facebookLeadsService;
    encryption;
    prisma;
    constructor(leadsService, facebookLeadsService, encryption, prisma) {
        this.leadsService = leadsService;
        this.facebookLeadsService = facebookLeadsService;
        this.encryption = encryption;
        this.prisma = prisma;
    }
    async getIntegrations(tenantId, projectId, user) {
        return this.leadsService.getIntegrations(projectId, tenantId, user.sub);
    }
    async getIntegration(tenantId, projectId, platform, user) {
        return this.leadsService.getIntegration(projectId, tenantId, user.sub, platform);
    }
    async createIntegration(tenantId, projectId, dto, user) {
        return this.leadsService.createIntegration(projectId, tenantId, user.sub, dto);
    }
    async updateIntegration(tenantId, projectId, platform, dto, user) {
        return this.leadsService.updateIntegration(projectId, tenantId, user.sub, platform, dto);
    }
    async deleteIntegration(tenantId, projectId, platform, user) {
        await this.leadsService.deleteIntegration(projectId, tenantId, user.sub, platform);
    }
    async getForms(tenantId, projectId, user) {
        return this.leadsService.getForms(projectId, tenantId, user.sub);
    }
    async getForm(tenantId, projectId, formId, user) {
        return this.leadsService.getForm(projectId, tenantId, user.sub, formId);
    }
    async createForm(tenantId, projectId, dto, user) {
        return this.leadsService.createForm(projectId, tenantId, user.sub, dto);
    }
    async updateForm(tenantId, projectId, formId, dto, user) {
        return this.leadsService.updateForm(projectId, tenantId, user.sub, formId, dto);
    }
    async deleteForm(tenantId, projectId, formId, user) {
        await this.leadsService.deleteForm(projectId, tenantId, user.sub, formId);
    }
    async getLeads(tenantId, projectId, query, user) {
        return this.leadsService.getLeads(projectId, tenantId, user.sub, query);
    }
    async getLeadStats(tenantId, projectId, query, user) {
        return this.leadsService.getLeadStats(projectId, tenantId, user.sub, query);
    }
    async getNotificationConfigs(tenantId, projectId, user) {
        return this.leadsService.getNotificationConfigs(projectId, tenantId, user.sub);
    }
    async createNotificationConfig(tenantId, projectId, dto, user) {
        return this.leadsService.createNotificationConfig(projectId, tenantId, user.sub, dto);
    }
    async updateNotificationConfig(tenantId, projectId, configId, dto, user) {
        return this.leadsService.updateNotificationConfig(projectId, tenantId, user.sub, configId, dto);
    }
    async deleteNotificationConfig(tenantId, projectId, configId, user) {
        await this.leadsService.deleteNotificationConfig(projectId, tenantId, user.sub, configId);
    }
    async getFacebookOAuthUrl(tenantId, projectId, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        const url = this.facebookLeadsService.getOAuthUrl(projectId, tenantId);
        return { url };
    }
    async getFacebookPages(tenantId, projectId, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        const integration = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
        });
        if (!integration || !integration.accessTokenEncrypted) {
            return { pages: [] };
        }
        const accessToken = this.encryption.decrypt(integration.accessTokenEncrypted);
        const pages = await this.facebookLeadsService.getPages(accessToken);
        return { pages };
    }
    async getFacebookForms(tenantId, projectId, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        const integration = await this.prisma.leadIntegration.findUnique({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
        });
        if (!integration || !integration.accessTokenEncrypted || !integration.pageId) {
            return { forms: [] };
        }
        const accessToken = this.encryption.decrypt(integration.accessTokenEncrypted);
        const forms = await this.facebookLeadsService.getLeadForms(integration.pageId, accessToken);
        return { forms };
    }
    async selectFacebookPage(tenantId, projectId, body, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        const encryptedToken = this.encryption.encrypt(body.pageAccessToken);
        await this.prisma.leadIntegration.upsert({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
            update: {
                pageId: body.pageId,
                pageName: body.pageName,
                accessTokenEncrypted: encryptedToken,
                status: client_1.LeadIntegrationStatus.ACTIVE,
            },
            create: {
                projectId,
                platform: client_1.LeadPlatform.FACEBOOK,
                pageId: body.pageId,
                pageName: body.pageName,
                accessTokenEncrypted: encryptedToken,
                status: client_1.LeadIntegrationStatus.ACTIVE,
            },
        });
        await this.facebookLeadsService.subscribeToLeadgenWebhook(body.pageId, body.pageAccessToken);
        return { success: true };
    }
    async selectFacebookForms(tenantId, projectId, body, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        await this.prisma.leadIntegration.update({
            where: {
                projectId_platform: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                },
            },
            data: {
                formIds: body.formIds,
            },
        });
        return { success: true };
    }
    async syncFacebookLeads(tenantId, projectId, user) {
        await this.leadsService.checkProjectAccess(projectId, tenantId, user.sub);
        const result = await this.facebookLeadsService.syncLeads(projectId);
        return result;
    }
};
exports.LeadsController = LeadsController;
__decorate([
    (0, common_1.Get)('integrations'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all lead integrations for a project' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of integrations' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getIntegrations", null);
__decorate([
    (0, common_1.Get)('integrations/:platform'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get specific lead integration' }),
    (0, swagger_1.ApiParam)({ name: 'platform', enum: client_1.LeadPlatform }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Integration details' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('platform')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getIntegration", null);
__decorate([
    (0, common_1.Post)('integrations'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create lead integration' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Integration created' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, leads_dto_1.CreateLeadIntegrationDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "createIntegration", null);
__decorate([
    (0, common_1.Put)('integrations/:platform'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Update lead integration' }),
    (0, swagger_1.ApiParam)({ name: 'platform', enum: client_1.LeadPlatform }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Integration updated' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('platform')),
    __param(3, (0, common_1.Body)()),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, leads_dto_1.UpdateLeadIntegrationDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "updateIntegration", null);
__decorate([
    (0, common_1.Delete)('integrations/:platform'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete lead integration' }),
    (0, swagger_1.ApiParam)({ name: 'platform', enum: client_1.LeadPlatform }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Integration deleted' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('platform')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "deleteIntegration", null);
__decorate([
    (0, common_1.Get)('forms'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all lead forms for a project' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of forms' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getForms", null);
__decorate([
    (0, common_1.Get)('forms/:formId'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get specific lead form' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Form details' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('formId')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getForm", null);
__decorate([
    (0, common_1.Post)('forms'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create lead form' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Form created' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, leads_dto_1.CreateLeadFormDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "createForm", null);
__decorate([
    (0, common_1.Put)('forms/:formId'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Update lead form' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Form updated' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('formId')),
    __param(3, (0, common_1.Body)()),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, leads_dto_1.UpdateLeadFormDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "updateForm", null);
__decorate([
    (0, common_1.Delete)('forms/:formId'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete lead form' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Form deleted' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('formId')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "deleteForm", null);
__decorate([
    (0, common_1.Get)(),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get leads list' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of leads' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, leads_dto_1.LeadQueryDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getLeads", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get lead statistics' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lead statistics' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, leads_dto_1.LeadQueryDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getLeadStats", null);
__decorate([
    (0, common_1.Get)('notifications'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get notification configs' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of notification configs' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getNotificationConfigs", null);
__decorate([
    (0, common_1.Post)('notifications'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create notification config' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Notification config created' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, leads_dto_1.CreateNotificationConfigDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "createNotificationConfig", null);
__decorate([
    (0, common_1.Put)('notifications/:configId'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Update notification config' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Notification config updated' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('configId')),
    __param(3, (0, common_1.Body)()),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, leads_dto_1.UpdateNotificationConfigDto, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "updateNotificationConfig", null);
__decorate([
    (0, common_1.Delete)('notifications/:configId'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete notification config' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Notification config deleted' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Param)('configId')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "deleteNotificationConfig", null);
__decorate([
    (0, common_1.Get)('integrations/facebook/oauth-url'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get Facebook OAuth URL for Lead Ads' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'OAuth URL returned' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getFacebookOAuthUrl", null);
__decorate([
    (0, common_1.Get)('integrations/facebook/pages'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get Facebook Pages for Lead Ads' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of Facebook pages' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getFacebookPages", null);
__decorate([
    (0, common_1.Get)('integrations/facebook/forms'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get Facebook Lead Forms' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of lead forms' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "getFacebookForms", null);
__decorate([
    (0, common_1.Post)('integrations/facebook/select-page'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Select Facebook Page for Lead Ads' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Page selected' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "selectFacebookPage", null);
__decorate([
    (0, common_1.Post)('integrations/facebook/select-forms'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Select Facebook Lead Forms' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Forms selected' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "selectFacebookForms", null);
__decorate([
    (0, common_1.Post)('integrations/facebook/sync'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: 'Manually sync Facebook leads' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Sync completed' }),
    __param(0, (0, common_1.Param)('tenantId')),
    __param(1, (0, common_1.Param)('projectId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsController.prototype, "syncFacebookLeads", null);
exports.LeadsController = LeadsController = __decorate([
    (0, swagger_1.ApiTags)('leads'),
    (0, common_1.Controller)('tenants/:tenantId/projects/:projectId/leads'),
    __metadata("design:paramtypes", [leads_service_1.LeadsService,
        facebook_leads_service_1.FacebookLeadsService,
        encryption_service_1.EncryptionService,
        prisma_service_1.PrismaService])
], LeadsController);
let LeadsOAuthController = LeadsOAuthController_1 = class LeadsOAuthController {
    facebookLeadsService;
    encryption;
    prisma;
    configService;
    logger = new common_1.Logger(LeadsOAuthController_1.name);
    constructor(facebookLeadsService, encryption, prisma, configService) {
        this.facebookLeadsService = facebookLeadsService;
        this.encryption = encryption;
        this.prisma = prisma;
        this.configService = configService;
    }
    async facebookCallback(code, state, error, errorDescription, res) {
        const frontendUrl = this.configService.get('FRONTEND_URL', 'http://localhost:3000');
        if (error) {
            this.logger.error(`Facebook OAuth error: ${error} - ${errorDescription}`);
            return res.redirect(`${frontendUrl}/dashboard/leads/integrations?error=${encodeURIComponent(errorDescription || error)}`);
        }
        try {
            const { projectId, tenantId } = JSON.parse(Buffer.from(state, 'base64').toString());
            const { accessToken, expiresIn } = await this.facebookLeadsService.exchangeCodeForToken(code);
            const encryptedToken = this.encryption.encrypt(accessToken);
            const tokenExpiresAt = new Date(Date.now() + expiresIn * 1000);
            await this.prisma.leadIntegration.upsert({
                where: {
                    projectId_platform: {
                        projectId,
                        platform: client_1.LeadPlatform.FACEBOOK,
                    },
                },
                update: {
                    accessTokenEncrypted: encryptedToken,
                    tokenExpiresAt,
                    status: client_1.LeadIntegrationStatus.PENDING,
                    errorMessage: null,
                },
                create: {
                    projectId,
                    platform: client_1.LeadPlatform.FACEBOOK,
                    accessTokenEncrypted: encryptedToken,
                    tokenExpiresAt,
                    status: client_1.LeadIntegrationStatus.PENDING,
                },
            });
            return res.redirect(`${frontendUrl}/dashboard/${tenantId}/${projectId}/leads/integrations?platform=facebook&step=select-page`);
        }
        catch (err) {
            this.logger.error(`Facebook OAuth callback error: ${err}`);
            return res.redirect(`${frontendUrl}/dashboard/leads/integrations?error=${encodeURIComponent('Falha ao conectar com Facebook')}`);
        }
    }
    async facebookWebhook(mode, verifyToken, challenge, body, res) {
        if (mode === 'subscribe') {
            const expectedToken = this.configService.get('FACEBOOK_WEBHOOK_VERIFY_TOKEN');
            if (verifyToken === expectedToken) {
                this.logger.log('Facebook webhook verified');
                return res.status(200).send(challenge);
            }
            return res.sendStatus(403);
        }
        if (body.object === 'page') {
            try {
                await this.facebookLeadsService.processWebhook(body.entry);
            }
            catch (err) {
                this.logger.error(`Facebook webhook processing error: ${err}`);
            }
            return res.sendStatus(200);
        }
        return res.sendStatus(404);
    }
    async facebookWebhookVerify(mode, verifyToken, challenge, res) {
        if (mode === 'subscribe') {
            const expectedToken = this.configService.get('FACEBOOK_WEBHOOK_VERIFY_TOKEN');
            if (verifyToken === expectedToken) {
                this.logger.log('Facebook webhook verified');
                return res.status(200).send(challenge);
            }
        }
        return res.sendStatus(403);
    }
};
exports.LeadsOAuthController = LeadsOAuthController;
__decorate([
    (0, common_1.Get)('facebook/callback'),
    (0, swagger_1.ApiExcludeEndpoint)(),
    __param(0, (0, common_1.Query)('code')),
    __param(1, (0, common_1.Query)('state')),
    __param(2, (0, common_1.Query)('error')),
    __param(3, (0, common_1.Query)('error_description')),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsOAuthController.prototype, "facebookCallback", null);
__decorate([
    (0, common_1.Post)('facebook/webhook'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiExcludeEndpoint)(),
    __param(0, (0, common_1.Query)('hub.mode')),
    __param(1, (0, common_1.Query)('hub.verify_token')),
    __param(2, (0, common_1.Query)('hub.challenge')),
    __param(3, (0, common_1.Body)()),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], LeadsOAuthController.prototype, "facebookWebhook", null);
__decorate([
    (0, common_1.Get)('facebook/webhook'),
    (0, swagger_1.ApiExcludeEndpoint)(),
    __param(0, (0, common_1.Query)('hub.mode')),
    __param(1, (0, common_1.Query)('hub.verify_token')),
    __param(2, (0, common_1.Query)('hub.challenge')),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], LeadsOAuthController.prototype, "facebookWebhookVerify", null);
exports.LeadsOAuthController = LeadsOAuthController = LeadsOAuthController_1 = __decorate([
    (0, swagger_1.ApiTags)('leads-oauth'),
    (0, common_1.Controller)('leads/oauth'),
    __metadata("design:paramtypes", [facebook_leads_service_1.FacebookLeadsService,
        encryption_service_1.EncryptionService,
        prisma_service_1.PrismaService,
        config_1.ConfigService])
], LeadsOAuthController);
let PublicLeadsController = PublicLeadsController_1 = class PublicLeadsController {
    leadsService;
    apiKeysService;
    logger = new common_1.Logger(PublicLeadsController_1.name);
    constructor(leadsService, apiKeysService) {
        this.leadsService = leadsService;
        this.apiKeysService = apiKeysService;
    }
    async captureLead(dto, req) {
        const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.ip || '';
        const userAgent = req.headers['user-agent'] || '';
        const form = await this.leadsService['prisma'].leadFormConfig.findUnique({
            where: { id: dto.formId },
        });
        if (!form) {
            return { success: false, error: 'Form not found' };
        }
        return this.leadsService.captureLead(form.projectId, dto, ip, userAgent);
    }
    async captureLeadWebhook(dto, req) {
        const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.ip || '';
        const userAgent = req.headers['user-agent'] || '';
        const apiKey = req.headers['x-api-key'];
        if (!apiKey) {
            return {
                success: false,
                error: 'API Key required. Send it in the X-API-Key header.'
            };
        }
        const keyData = await this.apiKeysService.validateApiKey(apiKey);
        if (!keyData) {
            return {
                success: false,
                error: 'Invalid API Key'
            };
        }
        this.logger.log(`Lead webhook received for project ${keyData.projectId}`);
        return this.leadsService.captureWebhookLead(keyData.projectId, dto, ip, userAgent);
    }
};
exports.PublicLeadsController = PublicLeadsController;
__decorate([
    (0, common_1.Post)('capture'),
    (0, swagger_1.ApiOperation)({ summary: 'Capture lead from embedded form' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lead captured' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [leads_dto_1.CaptureLeadDto, Object]),
    __metadata("design:returntype", Promise)
], PublicLeadsController.prototype, "captureLead", null);
__decorate([
    (0, common_1.Post)('webhook'),
    (0, swagger_1.ApiOperation)({ summary: 'Capture lead via webhook using API Key' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lead captured successfully' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid or missing API Key' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [leads_dto_1.WebhookLeadDto, Object]),
    __metadata("design:returntype", Promise)
], PublicLeadsController.prototype, "captureLeadWebhook", null);
exports.PublicLeadsController = PublicLeadsController = PublicLeadsController_1 = __decorate([
    (0, swagger_1.ApiTags)('public-leads'),
    (0, common_1.Controller)('public/leads'),
    __metadata("design:paramtypes", [leads_service_1.LeadsService,
        api_keys_service_1.ApiKeysService])
], PublicLeadsController);
//# sourceMappingURL=leads.controller.js.map