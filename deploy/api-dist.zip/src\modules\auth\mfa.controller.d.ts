import { MfaService } from './mfa.service';
import { VerifyMfaDto, DisableMfaDto, RegenerateBackupCodesDto, MfaSetupResponseDto, MfaStatusResponseDto } from './dto/mfa.dto';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
export declare class MfaController {
    private readonly mfaService;
    constructor(mfaService: MfaService);
    getMfaStatus(user: JwtPayload): Promise<MfaStatusResponseDto>;
    setupMfa(user: JwtPayload): Promise<MfaSetupResponseDto>;
    verifyAndEnableMfa(user: JwtPayload, dto: VerifyMfaDto): Promise<{
        success: boolean;
        message: string;
    }>;
    disableMfa(user: JwtPayload, dto: DisableMfaDto): Promise<{
        success: boolean;
        message: string;
    }>;
    regenerateBackupCodes(user: JwtPayload, dto: RegenerateBackupCodesDto): Promise<{
        backupCodes: string[];
    }>;
}
//# sourceMappingURL=mfa.controller.d.ts.map