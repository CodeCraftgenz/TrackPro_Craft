import { Request, Response } from 'express';
import { LeadPlatform } from '@prisma/client';
import { ConfigService } from '@nestjs/config';
import { LeadsService } from './leads.service';
import { FacebookLeadsService, FacebookPage, FacebookForm } from './facebook-leads.service';
import { EncryptionService } from '../integrations/encryption.service';
import { PrismaService } from '../../prisma/prisma.service';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
import { CreateLeadIntegrationDto, UpdateLeadIntegrationDto, CreateLeadFormDto, UpdateLeadFormDto, CaptureLeadDto, CreateNotificationConfigDto, UpdateNotificationConfigDto, LeadQueryDto, WebhookLeadDto } from './dto/leads.dto';
import { ApiKeysService } from '../projects/api-keys.service';
export declare class LeadsController {
    private readonly leadsService;
    private readonly facebookLeadsService;
    private readonly encryption;
    private readonly prisma;
    constructor(leadsService: LeadsService, facebookLeadsService: FacebookLeadsService, encryption: EncryptionService, prisma: PrismaService);
    getIntegrations(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        lastSyncAt: Date | null;
        errorMessage: string | null;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    getIntegration(tenantId: string, projectId: string, platform: LeadPlatform, user: JwtPayload): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        lastSyncAt: Date | null;
        errorMessage: string | null;
        metadata: import("@prisma/client/runtime/library").JsonValue;
        createdAt: Date;
        updatedAt: Date;
    } | null>;
    createIntegration(tenantId: string, projectId: string, dto: CreateLeadIntegrationDto, user: JwtPayload): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        webhookSecret: string | null;
        hasAccessToken: boolean;
        createdAt: Date;
    }>;
    updateIntegration(tenantId: string, projectId: string, platform: LeadPlatform, dto: UpdateLeadIntegrationDto, user: JwtPayload): Promise<{
        id: string;
        platform: import("@prisma/client").$Enums.LeadPlatform;
        status: import("@prisma/client").$Enums.LeadIntegrationStatus;
        pageId: string | null;
        pageName: string | null;
        formIds: import("@prisma/client/runtime/library").JsonValue;
        hasAccessToken: boolean;
        updatedAt: Date;
    }>;
    deleteIntegration(tenantId: string, projectId: string, platform: LeadPlatform, user: JwtPayload): Promise<void>;
    getForms(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }[]>;
    getForm(tenantId: string, projectId: string, formId: string, user: JwtPayload): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    createForm(tenantId: string, projectId: string, dto: CreateLeadFormDto, user: JwtPayload): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    updateForm(tenantId: string, projectId: string, formId: string, dto: UpdateLeadFormDto, user: JwtPayload): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        fields: import("@prisma/client/runtime/library").JsonValue;
        styling: import("@prisma/client/runtime/library").JsonValue | null;
        redirectUrl: string | null;
        submitUrl: string | null;
        embedCode: string;
    }>;
    deleteForm(tenantId: string, projectId: string, formId: string, user: JwtPayload): Promise<void>;
    getLeads(tenantId: string, projectId: string, query: LeadQueryDto, user: JwtPayload): Promise<{
        leads: {
            custom_fields: any;
            created_at: string;
            lead_id: string;
            project_id: string;
            platform: string;
            form_id: string;
            form_name: string;
            email: string;
            name: string;
            phone: string;
            utm_source: string;
            utm_medium: string;
            utm_campaign: string;
            referrer: string;
            page_url: string;
            ip: string;
            user_agent: string;
        }[];
        total: number;
        limit: number;
        offset: number;
    }>;
    getLeadStats(tenantId: string, projectId: string, query: LeadQueryDto, user: JwtPayload): Promise<{
        totalLeads: number;
        leadsToday: number;
        byPlatform: {
            platform: string;
            count: number;
        }[];
        byForm: {
            formId: string;
            formName: string;
            count: number;
        }[];
        timeline: {
            date: string;
            count: number;
        }[];
    }>;
    getNotificationConfigs(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
    createNotificationConfig(tenantId: string, projectId: string, dto: CreateNotificationConfigDto, user: JwtPayload): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }>;
    updateNotificationConfig(tenantId: string, projectId: string, configId: string, dto: UpdateNotificationConfigDto, user: JwtPayload): Promise<{
        id: string;
        email: string | null;
        createdAt: Date;
        updatedAt: Date;
        enabled: boolean;
        projectId: string;
        webhookUrl: string | null;
        platforms: import("@prisma/client/runtime/library").JsonValue;
    }>;
    deleteNotificationConfig(tenantId: string, projectId: string, configId: string, user: JwtPayload): Promise<void>;
    getFacebookOAuthUrl(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        url: string;
    }>;
    getFacebookPages(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        pages: FacebookPage[];
    }>;
    getFacebookForms(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        forms: FacebookForm[];
    }>;
    selectFacebookPage(tenantId: string, projectId: string, body: {
        pageId: string;
        pageName: string;
        pageAccessToken: string;
    }, user: JwtPayload): Promise<{
        success: boolean;
    }>;
    selectFacebookForms(tenantId: string, projectId: string, body: {
        formIds: string[];
    }, user: JwtPayload): Promise<{
        success: boolean;
    }>;
    syncFacebookLeads(tenantId: string, projectId: string, user: JwtPayload): Promise<{
        synced: number;
        errors: number;
    }>;
}
export declare class LeadsOAuthController {
    private readonly facebookLeadsService;
    private readonly encryption;
    private readonly prisma;
    private readonly configService;
    private readonly logger;
    constructor(facebookLeadsService: FacebookLeadsService, encryption: EncryptionService, prisma: PrismaService, configService: ConfigService);
    facebookCallback(code: string, state: string, error: string, errorDescription: string, res: Response): Promise<void>;
    facebookWebhook(mode: string, verifyToken: string, challenge: string, body: {
        object: string;
        entry: unknown[];
    }, res: Response): Promise<Response<any, Record<string, any>>>;
    facebookWebhookVerify(mode: string, verifyToken: string, challenge: string, res: Response): Promise<Response<any, Record<string, any>>>;
}
export declare class PublicLeadsController {
    private readonly leadsService;
    private readonly apiKeysService;
    private readonly logger;
    constructor(leadsService: LeadsService, apiKeysService: ApiKeysService);
    captureLead(dto: CaptureLeadDto, req: Request): Promise<{
        success: boolean;
        leadId: string;
        redirectUrl: string | null;
    } | {
        success: boolean;
        error: string;
    }>;
    captureLeadWebhook(dto: WebhookLeadDto, req: Request): Promise<{
        success: boolean;
        leadId: string;
        message: string;
    } | {
        success: boolean;
        error: string;
    }>;
}
//# sourceMappingURL=leads.controller.d.ts.map