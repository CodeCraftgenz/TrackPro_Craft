"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuditService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = exports.AuditSeverity = exports.AuditResource = exports.AuditAction = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
var AuditAction;
(function (AuditAction) {
    AuditAction["USER_LOGIN"] = "user.login";
    AuditAction["USER_LOGIN_FAILED"] = "user.login_failed";
    AuditAction["USER_LOGOUT"] = "user.logout";
    AuditAction["USER_REGISTER"] = "user.register";
    AuditAction["PASSWORD_CHANGE"] = "user.password_change";
    AuditAction["PASSWORD_RESET_REQUEST"] = "user.password_reset_request";
    AuditAction["PASSWORD_RESET_COMPLETE"] = "user.password_reset_complete";
    AuditAction["MFA_ENABLED"] = "user.mfa_enabled";
    AuditAction["MFA_DISABLED"] = "user.mfa_disabled";
    AuditAction["MFA_BACKUP_USED"] = "user.mfa_backup_used";
    AuditAction["MFA_BACKUP_REGENERATED"] = "user.mfa_backup_regenerated";
    AuditAction["USER_CREATED"] = "user.created";
    AuditAction["USER_UPDATED"] = "user.updated";
    AuditAction["USER_DELETED"] = "user.deleted";
    AuditAction["USER_ROLE_CHANGED"] = "user.role_changed";
    AuditAction["TENANT_CREATED"] = "tenant.created";
    AuditAction["TENANT_UPDATED"] = "tenant.updated";
    AuditAction["TENANT_DELETED"] = "tenant.deleted";
    AuditAction["MEMBER_INVITED"] = "tenant.member_invited";
    AuditAction["MEMBER_REMOVED"] = "tenant.member_removed";
    AuditAction["PROJECT_CREATED"] = "project.created";
    AuditAction["PROJECT_UPDATED"] = "project.updated";
    AuditAction["PROJECT_DELETED"] = "project.deleted";
    AuditAction["PROJECT_ARCHIVED"] = "project.archived";
    AuditAction["API_KEY_CREATED"] = "api_key.created";
    AuditAction["API_KEY_REVOKED"] = "api_key.revoked";
    AuditAction["API_KEY_USED"] = "api_key.used";
    AuditAction["INTEGRATION_CONNECTED"] = "integration.connected";
    AuditAction["INTEGRATION_DISCONNECTED"] = "integration.disconnected";
    AuditAction["INTEGRATION_UPDATED"] = "integration.updated";
    AuditAction["INTEGRATION_ERROR"] = "integration.error";
    AuditAction["DATA_EXPORTED"] = "data.exported";
    AuditAction["DATA_DELETED"] = "data.deleted";
    AuditAction["DATA_ACCESS"] = "data.access";
    AuditAction["CONSENT_UPDATED"] = "privacy.consent_updated";
    AuditAction["DATA_SUBJECT_REQUEST"] = "privacy.data_subject_request";
    AuditAction["DATA_DELETION_REQUEST"] = "privacy.deletion_request";
    AuditAction["ADMIN_ACTION"] = "admin.action";
    AuditAction["SETTINGS_CHANGED"] = "admin.settings_changed";
    AuditAction["BACKUP_CREATED"] = "admin.backup_created";
})(AuditAction || (exports.AuditAction = AuditAction = {}));
var AuditResource;
(function (AuditResource) {
    AuditResource["USER"] = "user";
    AuditResource["TENANT"] = "tenant";
    AuditResource["PROJECT"] = "project";
    AuditResource["API_KEY"] = "api_key";
    AuditResource["INTEGRATION"] = "integration";
    AuditResource["EXPORT"] = "export";
    AuditResource["CONSENT"] = "consent";
    AuditResource["LEAD"] = "lead";
    AuditResource["SETTINGS"] = "settings";
})(AuditResource || (exports.AuditResource = AuditResource = {}));
var AuditSeverity;
(function (AuditSeverity) {
    AuditSeverity["INFO"] = "info";
    AuditSeverity["WARNING"] = "warning";
    AuditSeverity["CRITICAL"] = "critical";
})(AuditSeverity || (exports.AuditSeverity = AuditSeverity = {}));
let AuditService = AuditService_1 = class AuditService {
    prisma;
    configService;
    logger = new common_1.Logger(AuditService_1.name);
    retentionDays;
    constructor(prisma, configService) {
        this.prisma = prisma;
        this.configService = configService;
        this.retentionDays = this.configService.get('AUDIT_RETENTION_DAYS', 365);
    }
    async log(data) {
        try {
            const sanitizedPayload = this.sanitizePayload(data.payload);
            const severity = data.severity || this.getSeverityForAction(data.action);
            await this.prisma.auditLog.create({
                data: {
                    tenantId: data.tenantId,
                    actorUserId: data.actorUserId,
                    action: data.action,
                    resource: data.resource,
                    resourceId: data.resourceId,
                    payload: {
                        ...sanitizedPayload,
                        severity,
                        metadata: data.metadata,
                    },
                    ipAddress: data.ipAddress,
                    userAgent: data.userAgent,
                },
            });
            if (severity === AuditSeverity.CRITICAL) {
                this.logger.warn({
                    message: 'Critical audit event',
                    action: data.action,
                    resource: data.resource,
                    resourceId: data.resourceId,
                    tenantId: data.tenantId,
                    actorUserId: data.actorUserId,
                });
            }
            else {
                this.logger.debug({
                    message: 'Audit log created',
                    action: data.action,
                    resource: data.resource,
                    resourceId: data.resourceId,
                });
            }
        }
        catch (error) {
            this.logger.error('Failed to create audit log', error);
        }
    }
    async getLogs(tenantId, filters = {}) {
        const { limit = 50, offset = 0, action, resource, actorUserId, severity, startDate, endDate, searchTerm, } = filters;
        const where = { tenantId };
        if (action)
            where.action = action;
        if (resource)
            where.resource = resource;
        if (actorUserId)
            where.actorUserId = actorUserId;
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = startDate;
            if (endDate)
                where.createdAt.lte = endDate;
        }
        if (severity) {
            where.payload = {
                path: ['severity'],
                equals: severity,
            };
        }
        if (searchTerm) {
            where.OR = [
                { action: { contains: searchTerm } },
                { resource: { contains: searchTerm } },
                { resourceId: { contains: searchTerm } },
            ];
        }
        const [logs, total] = await Promise.all([
            this.prisma.auditLog.findMany({
                where,
                include: {
                    actor: {
                        select: {
                            id: true,
                            name: true,
                            email: true,
                        },
                    },
                },
                orderBy: { createdAt: 'desc' },
                take: limit,
                skip: offset,
            }),
            this.prisma.auditLog.count({ where }),
        ]);
        return { logs, total, limit, offset };
    }
    async getLogsForResource(tenantId, resource, resourceId, limit = 50) {
        return this.prisma.auditLog.findMany({
            where: {
                tenantId,
                resource,
                resourceId,
            },
            include: {
                actor: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
            },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }
    async getLogsForUser(tenantId, userId, limit = 50) {
        return this.prisma.auditLog.findMany({
            where: {
                tenantId,
                actorUserId: userId,
            },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }
    async getSecurityLogs(tenantId, days = 7) {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        const securityActions = [
            AuditAction.USER_LOGIN,
            AuditAction.USER_LOGIN_FAILED,
            AuditAction.PASSWORD_CHANGE,
            AuditAction.PASSWORD_RESET_REQUEST,
            AuditAction.PASSWORD_RESET_COMPLETE,
            AuditAction.MFA_ENABLED,
            AuditAction.MFA_DISABLED,
            AuditAction.MFA_BACKUP_USED,
            AuditAction.API_KEY_CREATED,
            AuditAction.API_KEY_REVOKED,
        ];
        return this.prisma.auditLog.findMany({
            where: {
                tenantId,
                action: { in: securityActions },
                createdAt: { gte: startDate },
            },
            include: {
                actor: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
    }
    async getAuditStats(tenantId, days = 30) {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        const [totalLogs, actionBreakdown, dailyActivity] = await Promise.all([
            this.prisma.auditLog.count({
                where: {
                    tenantId,
                    createdAt: { gte: startDate },
                },
            }),
            this.prisma.auditLog.groupBy({
                by: ['action'],
                where: {
                    tenantId,
                    createdAt: { gte: startDate },
                },
                _count: { action: true },
                orderBy: { _count: { action: 'desc' } },
                take: 10,
            }),
            this.prisma.$queryRaw `
        SELECT DATE(created_at) as date, COUNT(*) as count
        FROM audit_logs
        WHERE tenant_id = ${tenantId}
        AND created_at >= ${startDate}
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `,
        ]);
        return {
            totalLogs,
            actionBreakdown: actionBreakdown.map((item) => ({
                action: item.action,
                count: item._count.action,
            })),
            dailyActivity,
        };
    }
    async exportLogs(tenantId, startDate, endDate) {
        const logs = await this.prisma.auditLog.findMany({
            where: {
                tenantId,
                createdAt: {
                    gte: startDate,
                    lte: endDate,
                },
            },
            include: {
                actor: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
            },
            orderBy: { createdAt: 'asc' },
        });
        const headers = [
            'Timestamp',
            'Action',
            'Resource',
            'Resource ID',
            'Actor Name',
            'Actor Email',
            'IP Address',
            'User Agent',
            'Payload',
        ];
        const rows = logs.map((log) => [
            log.createdAt.toISOString(),
            log.action,
            log.resource,
            log.resourceId || '',
            log.actor?.name || 'System',
            log.actor?.email || '',
            log.ipAddress || '',
            log.userAgent || '',
            JSON.stringify(log.payload || {}),
        ]);
        const csv = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
        return csv;
    }
    async cleanupOldLogs() {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - this.retentionDays);
        const result = await this.prisma.auditLog.deleteMany({
            where: {
                createdAt: { lt: cutoffDate },
            },
        });
        this.logger.log(`Cleaned up ${result.count} audit logs older than ${this.retentionDays} days`);
        return result.count;
    }
    sanitizePayload(payload) {
        if (!payload)
            return undefined;
        const sensitiveKeys = [
            'password',
            'passwordHash',
            'token',
            'accessToken',
            'refreshToken',
            'apiKey',
            'secret',
            'credential',
            'mfaSecret',
            'backupCodes',
        ];
        const sanitized = { ...payload };
        for (const key of Object.keys(sanitized)) {
            if (sensitiveKeys.some((sk) => key.toLowerCase().includes(sk.toLowerCase()))) {
                sanitized[key] = '[REDACTED]';
            }
        }
        return sanitized;
    }
    getSeverityForAction(action) {
        const criticalActions = [
            AuditAction.USER_DELETED,
            AuditAction.TENANT_DELETED,
            AuditAction.PROJECT_DELETED,
            AuditAction.DATA_DELETED,
            AuditAction.MFA_DISABLED,
            AuditAction.API_KEY_REVOKED,
            AuditAction.DATA_DELETION_REQUEST,
        ];
        const warningActions = [
            AuditAction.USER_LOGIN_FAILED,
            AuditAction.PASSWORD_RESET_REQUEST,
            AuditAction.MFA_BACKUP_USED,
            AuditAction.INTEGRATION_ERROR,
            AuditAction.USER_ROLE_CHANGED,
        ];
        if (criticalActions.includes(action)) {
            return AuditSeverity.CRITICAL;
        }
        if (warningActions.includes(action)) {
            return AuditSeverity.WARNING;
        }
        return AuditSeverity.INFO;
    }
};
exports.AuditService = AuditService;
exports.AuditService = AuditService = AuditService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], AuditService);
//# sourceMappingURL=audit.service.js.map