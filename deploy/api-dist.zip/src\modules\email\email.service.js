"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EmailService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const sgMail = __importStar(require("@sendgrid/mail"));
const nodemailer = __importStar(require("nodemailer"));
let EmailService = EmailService_1 = class EmailService {
    configService;
    logger = new common_1.Logger(EmailService_1.name);
    provider;
    defaultFrom;
    smtpTransporter;
    constructor(configService) {
        this.configService = configService;
        this.provider = this.configService.get('EMAIL_PROVIDER', 'console');
        this.defaultFrom = this.configService.get('EMAIL_FROM', 'TrackPro <noreply@trackpro.io>');
        this.initializeProvider();
    }
    initializeProvider() {
        switch (this.provider) {
            case 'sendgrid':
                const apiKey = this.configService.get('SENDGRID_API_KEY');
                if (!apiKey) {
                    throw new Error('SENDGRID_API_KEY is required when EMAIL_PROVIDER is sendgrid');
                }
                sgMail.setApiKey(apiKey);
                this.logger.log('Email provider initialized: SendGrid');
                break;
            case 'smtp':
                const host = this.configService.get('SMTP_HOST');
                const port = this.configService.get('SMTP_PORT', 587);
                const user = this.configService.get('SMTP_USER');
                const pass = this.configService.get('SMTP_PASS');
                if (!host || !user || !pass) {
                    throw new Error('SMTP_HOST, SMTP_USER, and SMTP_PASS are required when EMAIL_PROVIDER is smtp');
                }
                this.smtpTransporter = nodemailer.createTransport({
                    host,
                    port,
                    secure: port === 465,
                    auth: { user, pass },
                });
                this.logger.log(`Email provider initialized: SMTP (${host}:${port})`);
                break;
            case 'console':
            default:
                this.logger.warn('Email provider: console (emails will be logged, not sent)');
                break;
        }
    }
    async send(options) {
        const from = options.from || this.defaultFrom;
        try {
            switch (this.provider) {
                case 'sendgrid':
                    return this.sendViaSendGrid({ ...options, from });
                case 'smtp':
                    return this.sendViaSMTP({ ...options, from });
                case 'console':
                default:
                    return this.sendViaConsole({ ...options, from });
            }
        }
        catch (error) {
            this.logger.error('Failed to send email', error);
            return {
                success: false,
                error: error.message,
            };
        }
    }
    async sendViaSendGrid(options) {
        const msg = {
            to: options.to,
            from: options.from,
            subject: options.subject,
            html: options.html,
            text: options.text,
            replyTo: options.replyTo,
        };
        if (options.templateId) {
            msg.templateId = options.templateId;
            msg.dynamicTemplateData = options.templateData;
        }
        if (options.attachments?.length) {
            msg.attachments = options.attachments.map((att) => ({
                filename: att.filename,
                content: typeof att.content === 'string'
                    ? att.content
                    : att.content.toString('base64'),
                type: att.contentType,
                disposition: 'attachment',
            }));
        }
        const [response] = await sgMail.send(msg);
        this.logger.debug(`Email sent via SendGrid to ${Array.isArray(options.to) ? options.to.join(', ') : options.to}`);
        return {
            success: true,
            messageId: response.headers['x-message-id'],
        };
    }
    async sendViaSMTP(options) {
        if (!this.smtpTransporter) {
            throw new Error('SMTP transporter not initialized');
        }
        const mailOptions = {
            from: options.from,
            to: Array.isArray(options.to) ? options.to.join(', ') : options.to,
            subject: options.subject,
            html: options.html,
            text: options.text,
            replyTo: options.replyTo,
        };
        if (options.attachments?.length) {
            mailOptions.attachments = options.attachments.map((att) => ({
                filename: att.filename,
                content: att.content,
                contentType: att.contentType,
            }));
        }
        const info = await this.smtpTransporter.sendMail(mailOptions);
        this.logger.debug(`Email sent via SMTP to ${Array.isArray(options.to) ? options.to.join(', ') : options.to}`);
        return {
            success: true,
            messageId: info.messageId,
        };
    }
    async sendViaConsole(options) {
        const to = Array.isArray(options.to) ? options.to.join(', ') : options.to;
        this.logger.log(`
========== EMAIL (Console Mode) ==========
From: ${options.from}
To: ${to}
Subject: ${options.subject}
ReplyTo: ${options.replyTo || 'N/A'}
-------------------------------------------
${options.text || options.html || '(no content)'}
==========================================
    `);
        return {
            success: true,
            messageId: `console_${Date.now()}`,
        };
    }
    async sendWelcomeEmail(to, name) {
        return this.send({
            to,
            subject: 'Bem-vindo ao TrackPro!',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #00E4F2;">Bem-vindo ao TrackPro!</h1>
          <p>Oi ${name},</p>
          <p>Obrigado por se cadastrar no TrackPro. Estamos empolgados em ter você conosco!</p>
          <p>Com o TrackPro você pode:</p>
          <ul>
            <li>Rastrear eventos first-party sem bloqueio de adblockers</li>
            <li>Capturar leads automaticamente</li>
            <li>Integrar com Meta CAPI para conversões</li>
            <li>Visualizar analytics em tempo real</li>
          </ul>
          <p>
            <a href="${this.configService.get('FRONTEND_URL')}/dashboard"
               style="background: #00E4F2; color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Acessar Dashboard
            </a>
          </p>
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Equipe TrackPro
          </p>
        </div>
      `,
        });
    }
    async sendPasswordResetEmail(to, name, resetToken) {
        const resetUrl = `${this.configService.get('FRONTEND_URL')}/reset-password?token=${resetToken}`;
        return this.send({
            to,
            subject: 'Redefinir senha - TrackPro',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #00E4F2;">Redefinir Senha</h1>
          <p>Oi ${name},</p>
          <p>Recebemos uma solicitação para redefinir sua senha. Clique no botão abaixo para criar uma nova senha:</p>
          <p>
            <a href="${resetUrl}"
               style="background: #00E4F2; color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Redefinir Senha
            </a>
          </p>
          <p style="color: #666; font-size: 14px;">
            Este link expira em 1 hora. Se você não solicitou a redefinição, ignore este email.
          </p>
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Equipe TrackPro
          </p>
        </div>
      `,
        });
    }
    async sendLeadNotificationEmail(to, leadData) {
        return this.send({
            to,
            subject: `Novo Lead Capturado - ${leadData.formName}`,
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #00E4F2;">Novo Lead Capturado!</h1>
          <p>Um novo lead foi capturado no projeto <strong>${leadData.projectName}</strong>:</p>
          <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Formulário:</strong> ${leadData.formName}</p>
            ${leadData.name ? `<p><strong>Nome:</strong> ${leadData.name}</p>` : ''}
            ${leadData.email ? `<p><strong>Email:</strong> ${leadData.email}</p>` : ''}
            ${leadData.phone ? `<p><strong>Telefone:</strong> ${leadData.phone}</p>` : ''}
          </div>
          <p>
            <a href="${this.configService.get('FRONTEND_URL')}/dashboard/leads"
               style="background: #00E4F2; color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Ver Todos os Leads
            </a>
          </p>
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            TrackPro - Lead Capture System
          </p>
        </div>
      `,
        });
    }
    async sendExportReadyEmail(to, exportData) {
        return this.send({
            to,
            subject: `Seu export está pronto - TrackPro`,
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #00E4F2;">Export Pronto!</h1>
          <p>Seu export de <strong>${exportData.type}</strong> está pronto para download.</p>
          <p>
            <a href="${exportData.downloadUrl}"
               style="background: #00E4F2; color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
              Baixar Export
            </a>
          </p>
          <p style="color: #666; font-size: 14px;">
            Este link expira em ${exportData.expiresAt.toLocaleString('pt-BR')}.
          </p>
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Equipe TrackPro
          </p>
        </div>
      `,
        });
    }
};
exports.EmailService = EmailService;
exports.EmailService = EmailService = EmailService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], EmailService);
//# sourceMappingURL=email.service.js.map