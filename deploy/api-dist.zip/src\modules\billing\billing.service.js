"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var BillingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const stripe_1 = __importDefault(require("stripe"));
const prisma_service_1 = require("../../prisma/prisma.service");
const audit_service_1 = require("../audit/audit.service");
const client_1 = require("@prisma/client");
let BillingService = BillingService_1 = class BillingService {
    prisma;
    configService;
    auditService;
    logger = new common_1.Logger(BillingService_1.name);
    stripe = null;
    webhookSecret;
    constructor(prisma, configService, auditService) {
        this.prisma = prisma;
        this.configService = configService;
        this.auditService = auditService;
        const stripeSecretKey = this.configService.get('STRIPE_SECRET_KEY');
        this.webhookSecret = this.configService.get('STRIPE_WEBHOOK_SECRET', '');
        if (stripeSecretKey) {
            this.stripe = new stripe_1.default(stripeSecretKey);
            this.logger.log('Stripe initialized');
        }
        else {
            this.logger.warn('Stripe not configured - billing features disabled');
        }
    }
    async getOrCreateStripeCustomer(tenantId) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
            include: { tenant: true },
        });
        if (subscription?.stripeCustomerId) {
            return subscription.stripeCustomerId;
        }
        const tenant = await this.prisma.tenant.findUnique({
            where: { id: tenantId },
            include: {
                memberships: {
                    where: { role: 'OWNER' },
                    include: { user: true },
                    take: 1,
                },
            },
        });
        if (!tenant) {
            throw new common_1.NotFoundException('Tenant not found');
        }
        const ownerEmail = tenant.memberships[0]?.user?.email || `tenant-${tenantId}@trackpro.app`;
        const customer = await this.stripe.customers.create({
            email: ownerEmail,
            name: tenant.name,
            metadata: {
                tenantId: tenant.id,
                tenantSlug: tenant.slug,
            },
        });
        if (subscription) {
            await this.prisma.subscription.update({
                where: { tenantId },
                data: { stripeCustomerId: customer.id },
            });
        }
        return customer.id;
    }
    async createCheckoutSession(dto) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        const plan = await this.prisma.plan.findUnique({
            where: { tier: dto.planTier },
        });
        if (!plan) {
            throw new common_1.NotFoundException('Plan not found');
        }
        const priceId = dto.billingInterval === 'yearly'
            ? plan.stripePriceIdYearly
            : plan.stripePriceIdMonthly;
        if (!priceId) {
            throw new common_1.BadRequestException('Price not configured for this plan');
        }
        const customerId = await this.getOrCreateStripeCustomer(dto.tenantId);
        const session = await this.stripe.checkout.sessions.create({
            customer: customerId,
            mode: 'subscription',
            payment_method_types: ['card'],
            line_items: [
                {
                    price: priceId,
                    quantity: 1,
                },
            ],
            success_url: dto.successUrl,
            cancel_url: dto.cancelUrl,
            subscription_data: {
                trial_period_days: dto.planTier !== client_1.PlanTier.FREE ? 14 : undefined,
                metadata: {
                    tenantId: dto.tenantId,
                    planId: plan.id,
                    billingInterval: dto.billingInterval,
                },
            },
            metadata: {
                tenantId: dto.tenantId,
                planId: plan.id,
            },
            allow_promotion_codes: true,
            billing_address_collection: 'required',
        });
        return { url: session.url };
    }
    async createCustomerPortalSession(dto) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId: dto.tenantId },
        });
        if (!subscription?.stripeCustomerId) {
            throw new common_1.BadRequestException('No billing account found');
        }
        const session = await this.stripe.billingPortal.sessions.create({
            customer: subscription.stripeCustomerId,
            return_url: dto.returnUrl,
        });
        return { url: session.url };
    }
    async getSubscription(tenantId) {
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
            include: { plan: true },
        });
        if (!subscription) {
            return null;
        }
        const price = subscription.billingInterval === 'yearly'
            ? subscription.plan.yearlyPrice
            : subscription.plan.monthlyPrice;
        return {
            id: subscription.id,
            status: subscription.status,
            plan: {
                id: subscription.plan.id,
                name: subscription.plan.name,
                tier: subscription.plan.tier,
                price,
            },
            billingInterval: subscription.billingInterval,
            currentPeriodStart: subscription.currentPeriodStart,
            currentPeriodEnd: subscription.currentPeriodEnd,
            cancelAtPeriodEnd: subscription.cancelAtPeriodEnd,
            trialEnd: subscription.trialEnd,
        };
    }
    async getUsageSummary(tenantId) {
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
            include: { plan: true },
        });
        if (!subscription) {
            return {
                eventsCount: 0,
                eventsLimit: 10000,
                eventsPercentage: 0,
                projectsCount: 0,
                projectsLimit: 1,
                teamMembersCount: 1,
                teamMembersLimit: 1,
            };
        }
        const now = new Date();
        const [projectsCount, teamMembersCount, usageRecord] = await Promise.all([
            this.prisma.project.count({ where: { tenantId } }),
            this.prisma.membership.count({ where: { tenantId } }),
            this.prisma.usageRecord.findFirst({
                where: {
                    subscriptionId: subscription.id,
                    periodStart: { lte: now },
                    periodEnd: { gte: now },
                },
            }),
        ]);
        const eventsCount = usageRecord?.eventsCount || 0;
        const eventsLimit = subscription.plan.maxEventsPerMonth;
        return {
            eventsCount,
            eventsLimit,
            eventsPercentage: Math.round((eventsCount / eventsLimit) * 100),
            projectsCount,
            projectsLimit: subscription.plan.maxProjects,
            teamMembersCount,
            teamMembersLimit: subscription.plan.maxTeamMembers,
        };
    }
    async getInvoices(tenantId, limit = 10) {
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
        });
        if (!subscription) {
            return [];
        }
        return this.prisma.invoice.findMany({
            where: { subscriptionId: subscription.id },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }
    async cancelSubscription(tenantId, userId) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
        });
        if (!subscription?.stripeSubscriptionId) {
            throw new common_1.BadRequestException('No active subscription found');
        }
        await this.stripe.subscriptions.update(subscription.stripeSubscriptionId, {
            cancel_at_period_end: true,
        });
        await this.prisma.subscription.update({
            where: { tenantId },
            data: {
                cancelAtPeriodEnd: true,
                canceledAt: new Date(),
            },
        });
        await this.auditService.log({
            tenantId,
            actorUserId: userId,
            action: audit_service_1.AuditAction.SETTINGS_CHANGED,
            resource: audit_service_1.AuditResource.SETTINGS,
            resourceId: subscription.id,
            payload: { action: 'subscription_canceled' },
        });
    }
    async resumeSubscription(tenantId, userId) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
        });
        if (!subscription?.stripeSubscriptionId) {
            throw new common_1.BadRequestException('No subscription found');
        }
        await this.stripe.subscriptions.update(subscription.stripeSubscriptionId, {
            cancel_at_period_end: false,
        });
        await this.prisma.subscription.update({
            where: { tenantId },
            data: {
                cancelAtPeriodEnd: false,
                canceledAt: null,
            },
        });
        await this.auditService.log({
            tenantId,
            actorUserId: userId,
            action: audit_service_1.AuditAction.SETTINGS_CHANGED,
            resource: audit_service_1.AuditResource.SETTINGS,
            resourceId: subscription.id,
            payload: { action: 'subscription_resumed' },
        });
    }
    async handleWebhook(payload, signature) {
        if (!this.stripe) {
            throw new common_1.BadRequestException('Billing is not configured');
        }
        let event;
        try {
            event = this.stripe.webhooks.constructEvent(payload, signature, this.webhookSecret);
        }
        catch (err) {
            this.logger.error('Webhook signature verification failed', err);
            throw new common_1.BadRequestException('Invalid webhook signature');
        }
        this.logger.log(`Processing webhook event: ${event.type}`);
        switch (event.type) {
            case 'checkout.session.completed':
                await this.handleCheckoutCompleted(event.data.object);
                break;
            case 'customer.subscription.created':
            case 'customer.subscription.updated':
                await this.handleSubscriptionUpdated(event.data.object);
                break;
            case 'customer.subscription.deleted':
                await this.handleSubscriptionDeleted(event.data.object);
                break;
            case 'invoice.paid':
                await this.handleInvoicePaid(event.data.object);
                break;
            case 'invoice.payment_failed':
                await this.handleInvoicePaymentFailed(event.data.object);
                break;
            default:
                this.logger.debug(`Unhandled webhook event: ${event.type}`);
        }
    }
    async handleCheckoutCompleted(session) {
        const tenantId = session.metadata?.tenantId;
        const planId = session.metadata?.planId;
        if (!tenantId || !planId) {
            this.logger.warn('Missing metadata in checkout session');
            return;
        }
        this.logger.log(`Checkout completed for tenant ${tenantId}`);
    }
    async handleSubscriptionUpdated(stripeSubscription) {
        const tenantId = stripeSubscription.metadata?.tenantId;
        const planId = stripeSubscription.metadata?.planId;
        const billingInterval = stripeSubscription.metadata?.billingInterval || 'monthly';
        if (!tenantId) {
            this.logger.warn('Missing tenantId in subscription metadata');
            return;
        }
        const status = this.mapStripeStatus(stripeSubscription.status);
        const periodStart = stripeSubscription.current_period_start || stripeSubscription.currentPeriodStart;
        const periodEnd = stripeSubscription.current_period_end || stripeSubscription.currentPeriodEnd;
        await this.prisma.subscription.upsert({
            where: { tenantId },
            create: {
                tenantId,
                planId: planId || (await this.getDefaultPlanId()),
                status,
                stripeCustomerId: stripeSubscription.customer,
                stripeSubscriptionId: stripeSubscription.id,
                billingInterval,
                currentPeriodStart: new Date(periodStart * 1000),
                currentPeriodEnd: new Date(periodEnd * 1000),
                trialStart: stripeSubscription.trial_start
                    ? new Date(stripeSubscription.trial_start * 1000)
                    : null,
                trialEnd: stripeSubscription.trial_end
                    ? new Date(stripeSubscription.trial_end * 1000)
                    : null,
                cancelAtPeriodEnd: stripeSubscription.cancel_at_period_end,
            },
            update: {
                status,
                currentPeriodStart: new Date(periodStart * 1000),
                currentPeriodEnd: new Date(periodEnd * 1000),
                trialEnd: stripeSubscription.trial_end
                    ? new Date(stripeSubscription.trial_end * 1000)
                    : null,
                cancelAtPeriodEnd: stripeSubscription.cancel_at_period_end,
            },
        });
        this.logger.log(`Subscription updated for tenant ${tenantId}: ${status}`);
    }
    async handleSubscriptionDeleted(stripeSubscription) {
        const tenantId = stripeSubscription.metadata?.tenantId;
        if (!tenantId) {
            return;
        }
        const freePlan = await this.prisma.plan.findUnique({
            where: { tier: client_1.PlanTier.FREE },
        });
        if (freePlan) {
            await this.prisma.subscription.update({
                where: { tenantId },
                data: {
                    planId: freePlan.id,
                    status: client_1.SubscriptionStatus.CANCELED,
                    stripeSubscriptionId: null,
                },
            });
        }
        this.logger.log(`Subscription deleted for tenant ${tenantId}`);
    }
    async handleInvoicePaid(invoice) {
        const invoiceSubscription = invoice.subscription;
        if (!invoiceSubscription) {
            return;
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { stripeSubscriptionId: invoiceSubscription },
        });
        if (!subscription) {
            return;
        }
        await this.prisma.invoice.upsert({
            where: { stripeInvoiceId: invoice.id },
            create: {
                subscriptionId: subscription.id,
                stripeInvoiceId: invoice.id,
                amountDue: invoice.amount_due,
                amountPaid: invoice.amount_paid,
                currency: invoice.currency,
                status: client_1.PaymentStatus.SUCCEEDED,
                invoiceUrl: invoice.hosted_invoice_url || undefined,
                invoicePdf: invoice.invoice_pdf || undefined,
                periodStart: new Date(invoice.period_start * 1000),
                periodEnd: new Date(invoice.period_end * 1000),
                paidAt: new Date(),
            },
            update: {
                amountPaid: invoice.amount_paid,
                status: client_1.PaymentStatus.SUCCEEDED,
                paidAt: new Date(),
            },
        });
        this.logger.log(`Invoice paid for subscription ${subscription.id}`);
    }
    async handleInvoicePaymentFailed(invoice) {
        const invoiceSubscription = invoice.subscription;
        if (!invoiceSubscription) {
            return;
        }
        const subscription = await this.prisma.subscription.findUnique({
            where: { stripeSubscriptionId: invoiceSubscription },
        });
        if (!subscription) {
            return;
        }
        await this.prisma.invoice.upsert({
            where: { stripeInvoiceId: invoice.id },
            create: {
                subscriptionId: subscription.id,
                stripeInvoiceId: invoice.id,
                amountDue: invoice.amount_due,
                amountPaid: 0,
                currency: invoice.currency,
                status: client_1.PaymentStatus.FAILED,
                periodStart: new Date(invoice.period_start * 1000),
                periodEnd: new Date(invoice.period_end * 1000),
            },
            update: {
                status: client_1.PaymentStatus.FAILED,
            },
        });
        this.logger.warn(`Invoice payment failed for subscription ${subscription.id}`);
    }
    mapStripeStatus(stripeStatus) {
        const statusMap = {
            trialing: client_1.SubscriptionStatus.TRIALING,
            active: client_1.SubscriptionStatus.ACTIVE,
            past_due: client_1.SubscriptionStatus.PAST_DUE,
            canceled: client_1.SubscriptionStatus.CANCELED,
            unpaid: client_1.SubscriptionStatus.UNPAID,
            incomplete: client_1.SubscriptionStatus.INCOMPLETE,
            incomplete_expired: client_1.SubscriptionStatus.INCOMPLETE_EXPIRED,
        };
        return statusMap[stripeStatus] || client_1.SubscriptionStatus.ACTIVE;
    }
    async getDefaultPlanId() {
        const freePlan = await this.prisma.plan.findUnique({
            where: { tier: client_1.PlanTier.FREE },
        });
        if (!freePlan) {
            throw new Error('Free plan not configured');
        }
        return freePlan.id;
    }
    async incrementEventCount(tenantId, count = 1) {
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
        });
        if (!subscription) {
            return;
        }
        const now = new Date();
        const periodStart = subscription.currentPeriodStart || new Date(now.getFullYear(), now.getMonth(), 1);
        const periodEnd = subscription.currentPeriodEnd || new Date(now.getFullYear(), now.getMonth() + 1, 0);
        await this.prisma.usageRecord.upsert({
            where: {
                subscriptionId_periodStart: {
                    subscriptionId: subscription.id,
                    periodStart,
                },
            },
            create: {
                subscriptionId: subscription.id,
                periodStart,
                periodEnd,
                eventsCount: count,
            },
            update: {
                eventsCount: { increment: count },
            },
        });
    }
    async checkPlanLimit(tenantId, limitType) {
        const subscription = await this.prisma.subscription.findUnique({
            where: { tenantId },
            include: { plan: true },
        });
        if (!subscription) {
            const limits = { projects: 1, events: 10000, team_members: 1 };
            const current = await this.getCurrentCount(tenantId, limitType);
            return {
                allowed: current < limits[limitType],
                current,
                limit: limits[limitType],
            };
        }
        const limitMap = {
            projects: subscription.plan.maxProjects,
            events: subscription.plan.maxEventsPerMonth,
            team_members: subscription.plan.maxTeamMembers,
        };
        const current = await this.getCurrentCount(tenantId, limitType, subscription.id);
        const limit = limitMap[limitType];
        return {
            allowed: current < limit,
            current,
            limit,
        };
    }
    async getCurrentCount(tenantId, limitType, subscriptionId) {
        switch (limitType) {
            case 'projects':
                return this.prisma.project.count({ where: { tenantId } });
            case 'team_members':
                return this.prisma.membership.count({ where: { tenantId } });
            case 'events':
                if (!subscriptionId)
                    return 0;
                const now = new Date();
                const usage = await this.prisma.usageRecord.findFirst({
                    where: {
                        subscriptionId,
                        periodStart: { lte: now },
                        periodEnd: { gte: now },
                    },
                });
                return usage?.eventsCount || 0;
            default:
                return 0;
        }
    }
};
exports.BillingService = BillingService;
exports.BillingService = BillingService = BillingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        audit_service_1.AuditService])
], BillingService);
//# sourceMappingURL=billing.service.js.map