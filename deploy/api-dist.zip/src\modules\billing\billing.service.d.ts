import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { PlanTier, SubscriptionStatus } from '@prisma/client';
export interface CreateCheckoutSessionDto {
    tenantId: string;
    planTier: PlanTier;
    billingInterval: 'monthly' | 'yearly';
    successUrl: string;
    cancelUrl: string;
}
export interface CreateCustomerPortalSessionDto {
    tenantId: string;
    returnUrl: string;
}
export interface SubscriptionDetails {
    id: string;
    status: SubscriptionStatus;
    plan: {
        id: string;
        name: string;
        tier: PlanTier;
        price: number;
    };
    billingInterval: string;
    currentPeriodStart: Date | null;
    currentPeriodEnd: Date | null;
    cancelAtPeriodEnd: boolean;
    trialEnd: Date | null;
}
export interface UsageSummary {
    eventsCount: number;
    eventsLimit: number;
    eventsPercentage: number;
    projectsCount: number;
    projectsLimit: number;
    teamMembersCount: number;
    teamMembersLimit: number;
}
export declare class BillingService {
    private readonly prisma;
    private readonly configService;
    private readonly auditService;
    private readonly logger;
    private stripe;
    private readonly webhookSecret;
    constructor(prisma: PrismaService, configService: ConfigService, auditService: AuditService);
    getOrCreateStripeCustomer(tenantId: string): Promise<string>;
    createCheckoutSession(dto: CreateCheckoutSessionDto): Promise<{
        url: string;
    }>;
    createCustomerPortalSession(dto: CreateCustomerPortalSessionDto): Promise<{
        url: string;
    }>;
    getSubscription(tenantId: string): Promise<SubscriptionDetails | null>;
    getUsageSummary(tenantId: string): Promise<UsageSummary>;
    getInvoices(tenantId: string, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        status: import("@prisma/client").$Enums.PaymentStatus;
        subscriptionId: string;
        periodStart: Date;
        periodEnd: Date;
        stripeInvoiceId: string | null;
        amountDue: number;
        amountPaid: number;
        currency: string;
        invoiceUrl: string | null;
        invoicePdf: string | null;
        dueDate: Date | null;
        paidAt: Date | null;
    }[]>;
    cancelSubscription(tenantId: string, userId: string): Promise<void>;
    resumeSubscription(tenantId: string, userId: string): Promise<void>;
    handleWebhook(payload: Buffer, signature: string): Promise<void>;
    private handleCheckoutCompleted;
    private handleSubscriptionUpdated;
    private handleSubscriptionDeleted;
    private handleInvoicePaid;
    private handleInvoicePaymentFailed;
    private mapStripeStatus;
    private getDefaultPlanId;
    incrementEventCount(tenantId: string, count?: number): Promise<void>;
    checkPlanLimit(tenantId: string, limitType: 'projects' | 'events' | 'team_members'): Promise<{
        allowed: boolean;
        current: number;
        limit: number;
    }>;
    private getCurrentCount;
}
//# sourceMappingURL=billing.service.d.ts.map