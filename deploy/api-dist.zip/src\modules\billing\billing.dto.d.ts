import { PlanTier } from '@prisma/client';
export declare class CreateCheckoutSessionDto {
    planTier: PlanTier;
    billingInterval: 'monthly' | 'yearly';
    successUrl: string;
    cancelUrl: string;
}
export declare class CreatePortalSessionDto {
    returnUrl: string;
}
export declare class UpdateStripePriceIdsDto {
    tier: PlanTier;
    monthlyPriceId: string;
    yearlyPriceId: string;
}
export declare class PlanResponseDto {
    id: string;
    name: string;
    tier: PlanTier;
    description?: string;
    monthlyPrice: number;
    yearlyPrice: number;
    maxProjects: number;
    maxEventsPerMonth: number;
    maxTeamMembers: number;
    retentionDays: number;
    features: string[];
}
export declare class SubscriptionResponseDto {
    id: string;
    status: string;
    plan: {
        id: string;
        name: string;
        tier: PlanTier;
        price: number;
    };
    billingInterval: string;
    currentPeriodStart?: Date;
    currentPeriodEnd?: Date;
    cancelAtPeriodEnd: boolean;
    trialEnd?: Date;
}
export declare class UsageSummaryResponseDto {
    eventsCount: number;
    eventsLimit: number;
    eventsPercentage: number;
    projectsCount: number;
    projectsLimit: number;
    teamMembersCount: number;
    teamMembersLimit: number;
}
export declare class InvoiceResponseDto {
    id: string;
    amountDue: number;
    amountPaid: number;
    currency: string;
    status: string;
    invoiceUrl?: string;
    invoicePdf?: string;
    periodStart: Date;
    periodEnd: Date;
    paidAt?: Date;
    createdAt: Date;
}
export declare class CheckoutSessionResponseDto {
    url: string;
}
export declare class PlanLimitCheckResponseDto {
    allowed: boolean;
    current: number;
    limit: number;
}
export declare class PlanComparisonResponseDto {
    plans: Array<{
        id: string;
        name: string;
        tier: PlanTier;
        description?: string;
        monthlyPrice: number;
        yearlyPrice: number;
        limits: {
            projects: string | number;
            eventsPerMonth: string;
            teamMembers: string | number;
            retentionDays: number;
        };
    }>;
    features: Array<{
        key: string;
        label: string;
        availability: Record<PlanTier, boolean>;
    }>;
}
//# sourceMappingURL=billing.dto.d.ts.map